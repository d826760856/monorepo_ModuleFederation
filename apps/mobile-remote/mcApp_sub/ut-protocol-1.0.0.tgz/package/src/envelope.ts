import type { EnvelopeErrorInfo } from './errors'

/**
 * 协议版本。
 * 只在“破坏性语义变更”时递增；纯新增可选字段不递增（对端忽略即可）。
 */
export const PROTOCOL_VERSION = 1

/**
 * 传输层单通道名。
 *
 * 设计要点：无论底层是 wujie eventBus、postMessage 还是 MF bridge，
 * 通道上只有一个 `unifiedTodo`，具体语义完全由 Envelope.topic 表达。
 * 这样换传输方式时不需要改任何业务代码，也不会出现“每加一个功能就多一个通道名”的扩散。
 */
export const CHANNEL = 'unifiedTodo'

/** 端身份：宿主还是子应用 */
export type Role = 'host' | 'sub'

/**
 * 一个通信端点。
 *
 * `app` 是**应用身份**（远程应用名），同一应用的多个实例 `app` 相同；
 * `instanceId` 是**实例身份**（wujie 实例名，如 `guanghua-rru_WO123`），
 * 用来把「同一子应用同时开两个工单」的两条会话分开。
 *
 * 缺了 instanceId 时，宿主只按 app 过滤 —— 两个实例会互相收到对方的 hello，
 * 后开的那条会话就会拿到前一个工单的上下文（保活串数据）。
 */
export interface Peer {
  app: string
  role: Role
  instanceId?: string
  /**
   * 这个端点代表哪种承载面。
   *
   * - `detail`：整页详情载体（wujie），工单数据的提供方
   * - `feature`：工单里的关联功能模块（MF 组件），工单数据的消费方
   *
   * 只用于日志与投递校验（例如宿主要拒绝把 `order.get` 发给功能模块），
   * 不参与路由。省略时按未知处理。
   */
  surface?: Surface
}

/** 承载面：详情整页 / 功能模块 */
export type Surface = 'detail' | 'feature'

/**
 * 收件地址。
 *
 * 与 `Peer` 的区别：只要求给 role，app 可以省略。
 * 子应用在握手前并不知道宿主名，只能按 `{ role: 'host' }` 寻址；
 * 若强制要求完整 Peer，子应用就得先猜一个宿主名，猜错就是握手失败。
 */
export interface PeerRef {
  app?: string
  role: Role
  /** 省略 = 该应用的所有实例（只有握手期的广播才应该省略） */
  instanceId?: string
}

/** 消息种类：请求 / 响应 / 事件 */
export type EnvelopeKind = 'req' | 'res' | 'evt'

/**
 * 统一信封。所有跨应用消息都是它的实例，没有例外。
 *
 * - `id`：一次请求的关联 id，同时充当 traceId（响应、重试、日志都用它串起来）
 * - `seq`：发送方单调递增序号，接收方用它做乱序丢弃
 * - `ts`：发送时刻（ms），用于链路耗时统计
 * - `to`：接受单个端点或 `'*'`（广播，仅握手期使用）
 * - `idempotentKey`：重复投递的幂等键，接收方据此返回首次执行结果而不重复执行
 */
export interface Envelope<P = unknown> {
  v: number
  id: string
  seq: number
  ts: number
  from: Peer
  to: PeerRef | '*'
  kind: EnvelopeKind
  topic: string
  payload?: P
  idempotentKey?: string
  error?: EnvelopeErrorInfo
}

/** 是否为广播地址 */
export function isBroadcast(to: PeerRef | '*'): to is '*' {
  return to === '*'
}

/** 地址是否指向 self：role 必须相等，app / instanceId 省略时视为通配 */
export function peerMatches(to: PeerRef | '*', self: Peer): boolean {
  if (isBroadcast(to)) return true
  if (to.role !== self.role) return false
  if (to.app !== undefined && to.app !== self.app) return false
  if (to.instanceId !== undefined && to.instanceId !== self.instanceId) return false
  return true
}

/**
 * 两个端点是否是同一端。
 *
 * instanceId 只在**双方都给**的时候才参与比较 —— 单方面带 instanceId 的旧端
 * （或 standalone 模式下没有实例概念的场景）不应该因此被判定成"不是自己"，
 * 否则自己发出的消息不会被丢弃，会形成回环。
 */
export function samePeer(a: PeerRef, b: PeerRef): boolean {
  if (a.app !== b.app || a.role !== b.role) return false
  if (a.instanceId !== undefined && b.instanceId !== undefined) {
    return a.instanceId === b.instanceId
  }
  return true
}

/** 端点的展示名，用于日志与错误信息 */
export function peerName(peer: PeerRef | '*'): string {
  if (isBroadcast(peer)) return '*'
  const instance = peer.instanceId ? `#${peer.instanceId}` : ''
  return `${peer.app ?? '*'}(${peer.role})${instance}`
}
