/**
 * 语义目录：topic 命名的唯一事实来源。
 *
 * 所有 topic 必须从这里取，schema 校验也读这张表。
 * topic 一旦散成各端的字符串字面量，同一个含义出现两种拼写
 * （如 `'ui.action'` vs `'ui.actions.set'`）就只会在运行时静默失败。
 */
export const Topics = {
  // ── 会话层（SDK 内部消化，接入方不感知） ─────────────────────────
  SessionHello: 'session.hello',
  SessionWelcome: 'session.welcome',
  SessionClose: 'session.close',
  SessionPing: 'session.ping',
  SessionPong: 'session.pong',

  // ── 语义层 ────────────────────────────────────────────────────────
  // 工单快照归子应用所有：宿主只拉取、只渲染，不拼装。
  /** 宿主 → 子应用：拉取工单快照（按钮也在快照里，payload 携带当前上下文） */
  OrderGet: 'order.get',
  /** 子应用 → 宿主：推送工单快照变更 */
  OrderData: 'order.data',
  /** 宿主 → 子应用：工单上下文增量更新（切单、保活恢复、主题变更） */
  OrderContext: 'order.context',
  /** 子应用 → 宿主：上下文变更上报（宿主据此同步地址栏等） */
  ContextUpdate: 'context.update',
  /** 子应用 → 宿主：登记/更新订阅条目 */
  OrderStream: 'order.stream',
  /**
   * 宿主 → 功能模块：工单视图广播（一对多）。
   *
   * 数据源是详情载体上报的那一份快照，宿主投影成 `OrderView` 后发给所有已挂载的
   * 功能模块 —— 功能模块**不拉取**工单数据，所以这里只有 evt，没有对应的 req。
   */
  OrderView: 'order.view',
  /** 功能模块 → 宿主：上报自己的部分数据（宿主按模块 id 存，不解释语义） */
  FeatureData: 'feature.data',
  /** 宿主 → 子应用：按钮点击，必须回执 */
  ActionInvoke: 'action.invoke',
  /** 宿主 → 子应用：页面被挂起（保活前） */
  LifecyclePause: 'lifecycle.pause',
  /** 宿主 → 子应用：页面被恢复 */
  LifecycleResume: 'lifecycle.resume',
  /** 宿主 → 子应用：需要重新拉数据 */
  LifecycleRefresh: 'lifecycle.refresh',
  /** 宿主 → 子应用：容器已销毁，子应用做清理 */
  LifecycleDestroy: 'lifecycle.destroy',
  /** 子应用 → 宿主：弹 toast */
  NotifyToast: 'notify.toast',
  /** 子应用 → 宿主：关闭当前容器 */
  NotifyClose: 'notify.close',
  /** 子应用 → 宿主：跳转 */
  NotifyNavigate: 'notify.navigate',
  /** 子应用 → 宿主：取消订阅 */
  SubscriptionCancel: 'subscription.cancel',
} as const

export type Topic = (typeof Topics)[keyof typeof Topics]

export type TopicLayer = 'session' | 'semantic'

export type TopicDirection = 'host->sub' | 'sub->host' | 'both'

export type TopicKind = 'req' | 'res' | 'evt' | 'both'

export interface TopicSpec {
  readonly topic: Topic
  readonly layer: TopicLayer
  readonly direction: TopicDirection
  readonly kind: TopicKind
  readonly summary: string
}

/**
 * 语义目录。接入自检（@ut/check）与 schema 校验都基于这张表：
 * 目录里没有的 topic 一律视为非法，避免“约定写在文档里、代码里随手拼串”。
 */
export const TOPIC_CATALOG: readonly TopicSpec[] = [
  { topic: Topics.SessionHello, layer: 'session', direction: 'sub->host', kind: 'req', summary: '子应用广播自身身份与能力' },
  { topic: Topics.SessionWelcome, layer: 'session', direction: 'host->sub', kind: 'res', summary: '宿主确认握手并下发特性开关' },
  { topic: Topics.SessionClose, layer: 'session', direction: 'both', kind: 'evt', summary: '会话关闭通知' },
  { topic: Topics.SessionPing, layer: 'session', direction: 'both', kind: 'evt', summary: '心跳探测' },
  { topic: Topics.SessionPong, layer: 'session', direction: 'both', kind: 'evt', summary: '心跳应答' },

  { topic: Topics.OrderGet, layer: 'semantic', direction: 'host->sub', kind: 'req', summary: '拉取工单快照（子应用返回首屏数据）' },
  { topic: Topics.OrderData, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '推送工单快照变更' },
  { topic: Topics.OrderContext, layer: 'semantic', direction: 'host->sub', kind: 'evt', summary: '工单上下文增量更新' },
  { topic: Topics.ContextUpdate, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '上下文变更上报' },
  { topic: Topics.OrderStream, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '登记订阅条目与状态' },
  { topic: Topics.OrderView, layer: 'semantic', direction: 'host->sub', kind: 'evt', summary: '向功能模块广播工单视图（一对多）' },
  { topic: Topics.FeatureData, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '功能模块上报自己的部分数据' },
  { topic: Topics.ActionInvoke, layer: 'semantic', direction: 'host->sub', kind: 'req', summary: '按钮点击，返回处理结果' },
  { topic: Topics.LifecyclePause, layer: 'semantic', direction: 'host->sub', kind: 'evt', summary: '子应用即将被保活挂起' },
  { topic: Topics.LifecycleResume, layer: 'semantic', direction: 'host->sub', kind: 'evt', summary: '子应用从保活恢复' },
  { topic: Topics.LifecycleRefresh, layer: 'semantic', direction: 'host->sub', kind: 'req', summary: '要求子应用刷新数据' },
  { topic: Topics.LifecycleDestroy, layer: 'semantic', direction: 'host->sub', kind: 'evt', summary: '容器销毁，子应用清理' },
  { topic: Topics.NotifyToast, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '请求宿主弹提示' },
  { topic: Topics.NotifyClose, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '请求宿主关闭当前容器' },
  { topic: Topics.NotifyNavigate, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '请求宿主路由跳转' },
  { topic: Topics.SubscriptionCancel, layer: 'semantic', direction: 'sub->host', kind: 'evt', summary: '取消订阅' },
]

const CATALOG_BY_TOPIC = new Map<string, TopicSpec>(TOPIC_CATALOG.map((spec) => [spec.topic, spec]))

/** 查目录；未登记的 topic 返回 undefined */
export function lookupTopic(topic: string): TopicSpec | undefined {
  return CATALOG_BY_TOPIC.get(topic)
}

/** 是否为已登记的 topic */
export function isKnownTopic(topic: string): topic is Topic {
  return CATALOG_BY_TOPIC.has(topic)
}
