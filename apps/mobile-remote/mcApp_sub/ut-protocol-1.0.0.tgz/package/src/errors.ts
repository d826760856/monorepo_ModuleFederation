/**
 * 协议错误码。
 *
 * 注意：tsconfig 开启了 erasableSyntaxOnly，不能使用 enum，这里统一用 const 对象 + 联合类型。
 * 前端各处（宿主 / 子应用 / 接入自检 CLI）都从这里取码值，避免字符串散落。
 */
export const ProtocolErrorCode = {
  /** 请求超时（重试耗尽） */
  Timeout: 'TIMEOUT',
  /** 对端未注册该 topic 的处理器，或能力未声明 */
  NotSupported: 'NOT_SUPPORTED',
  /** 信封或 payload 不符合 schema */
  InvalidPayload: 'INVALID_PAYLOAD',
  /** 对端业务上拒绝了这次调用 */
  Rejected: 'REJECTED',
  /** 对端内部异常 */
  Internal: 'INTERNAL',
  /** 会话已关闭 */
  Closed: 'CLOSED',
} as const

export type ProtocolErrorCode = (typeof ProtocolErrorCode)[keyof typeof ProtocolErrorCode]

/** 信封上承载的错误信息（只出现在 res 上） */
export interface EnvelopeErrorInfo {
  code: ProtocolErrorCode
  message: string
}

export interface ProtocolErrorOptions {
  topic?: string
  traceId?: string
  cause?: unknown
}

export class ProtocolError extends Error {
  readonly code: ProtocolErrorCode
  readonly topic: string | undefined
  readonly traceId: string | undefined

  constructor(code: ProtocolErrorCode, message: string, options: ProtocolErrorOptions = {}) {
    super(message)
    this.name = 'ProtocolError'
    this.code = code
    this.topic = options.topic
    this.traceId = options.traceId
    if (options.cause !== undefined) {
      this.cause = options.cause
    }
  }
}

export function isProtocolError(value: unknown): value is ProtocolError {
  return value instanceof ProtocolError
}

/** 把任意异常归一成 ProtocolError，保证跨边界传递时带上错误码 */
export function toProtocolError(value: unknown, fallbackCode: ProtocolErrorCode = ProtocolErrorCode.Internal): ProtocolError {
  if (value instanceof ProtocolError) return value
  const message = value instanceof Error ? value.message : String(value)
  return new ProtocolError(fallbackCode, message || '未知错误', { cause: value })
}
