import {
  PROTOCOL_VERSION,
  peerMatches,
  samePeer,
  type Envelope,
  type EnvelopeKind,
  type Peer,
  type PeerRef,
} from './envelope'
import { ProtocolError, ProtocolErrorCode, toProtocolError, type EnvelopeErrorInfo } from './errors'
import { Topics } from './topics'
import type { Transport } from './transport'

export type SessionStatus = 'idle' | 'connecting' | 'ready' | 'closed'

/** 不关心返回值的处理器；req 用返回值作为响应 payload */
export type MessageHandler = (payload: unknown, envelope: Envelope) => unknown

/**
 * 处理器返回这个哨兵表示「这封消息不是给我的，不要回 res」。
 *
 * 典型场景：同一页面上开了多个容器，每个容器的 bus 都能收到所有 hello，
 * 只有 `appName` + `instanceId` 对得上的那个才该回 welcome；
 * 其余容器如果回了（哪怕是错误响应），会让子应用拿到一份错误的结果。
 */
export const NO_REPLY: unique symbol = Symbol('session.no-reply')

export interface SendOptions {
  to?: PeerRef | '*'
  id?: string
  idempotentKey?: string
}

export interface RequestOptions extends SendOptions {
  /** 单次等待窗口（ms），重试时按 2 的幂次放大 */
  timeout?: number
  /** 超时后额外重试次数 */
  retries?: number
}

export interface SessionOptions {
  self: Peer
  transport: Transport
  /** 默认收件人；握手期可为 '*'，握手完成后用 setDefaultTo 指向对端 */
  defaultTo?: PeerRef | '*'
  version?: number
  /** 只接受来自该端点的消息；'*' 表示不限（子应用在握手前必须为 '*'） */
  acceptFrom?: PeerRef | '*'
  requestTimeout?: number
  retries?: number
  /** 心跳间隔（ms），0 = 关闭心跳 */
  heartbeatInterval?: number
  /** 控制台通信日志；默认开启，排查主子握手时可传 false 关闭 */
  debug?: boolean
  onError?: (error: ProtocolError) => void
  createId?: () => string
}

export interface SessionStats {
  sent: number
  received: number
  dropped: number
  retries: number
  timeouts: number
  lastRttMs: number | undefined
}

interface PendingRequest {
  id: string
  topic: string
  payload: unknown
  target: PeerRef | '*'
  idempotentKey: string
  attempt: number
  retries: number
  baseTimeout: number
  startedAt: number
  resolve: (value: unknown) => void
  reject: (error: unknown) => void
  timer: ReturnType<typeof setTimeout> | undefined
}

interface CachedReply {
  payload: unknown
  error: EnvelopeErrorInfo | undefined
}

/** 单次等待窗口基数，配合 retries 形成 2s / 4s / 8s 退避 */
const DEFAULT_REQUEST_TIMEOUT = 2000
/** 默认重试 2 次 → 共 3 次尝试（2s、4s、8s），与设计文档一致 */
const DEFAULT_RETRIES = 2
/** 退避窗口上限，避免长时间挂起 */
const MAX_TIMEOUT_WINDOW = 8000
/** 幂等结果缓存上限，防止长连接下无限增长 */
const MAX_CACHED_REPLIES = 200
/** 心跳判定：连续 3 个周期无应答视为链路异常 */
const HEARTBEAT_MISS_FACTOR = 3

let idCounter = 0

function defaultCreateId(): string {
  const cryptoRef: Crypto | undefined = globalThis.crypto
  if (cryptoRef && typeof cryptoRef.randomUUID === 'function') {
    return cryptoRef.randomUUID()
  }
  idCounter += 1
  return `ut-${Date.now().toString(36)}-${idCounter.toString(36)}`
}

/**
 * 会话层。
 *
 * 职责边界（对应设计文档 §5.2）：
 * - 信封编解码与 seq 管理
 * - 请求-响应配对、超时重试、幂等去重
 * - 心跳与链路异常上报
 * - 语义层发布订阅（`emit` / `on` / `request`）
 *
 * **不负责**任何业务语义：宿主就是宿主，子应用就是子应用，同一个类两端通用。
 * 两端各写一份 session 时，字段、重试、校验会各自漂移，所以只留这一份。
 */
export class Session {
  readonly self: Peer

  private readonly transport: Transport
  private readonly version: number
  private readonly acceptFrom: PeerRef | '*'
  private readonly requestTimeout: number
  private readonly retries: number
  private readonly heartbeatInterval: number
  private readonly debug: boolean
  private readonly onError: ((error: ProtocolError) => void) | undefined
  private readonly createId: () => string
  private readonly unsubscribe: () => void
  private readonly counters: SessionStats = {
    sent: 0,
    received: 0,
    dropped: 0,
    retries: 0,
    timeouts: 0,
    lastRttMs: undefined,
  }

  private defaultTo: PeerRef | '*'
  private statusValue: SessionStatus = 'idle'
  private seqCounter = 0
  private closed = false
  private readonly pending = new Map<string, PendingRequest>()
  private readonly handlers = new Map<string, Set<MessageHandler>>()
  private readonly replyCache = new Map<string, CachedReply>()
  private readonly lastSeqs = new Map<string, number>()
  private heartbeatTimer: ReturnType<typeof setInterval> | undefined
  private lastPongAt = 0

  constructor(options: SessionOptions) {
    this.self = options.self
    this.transport = options.transport
    this.defaultTo = options.defaultTo ?? '*'
    this.version = options.version ?? PROTOCOL_VERSION
    this.acceptFrom = options.acceptFrom ?? '*'
    this.requestTimeout = options.requestTimeout ?? DEFAULT_REQUEST_TIMEOUT
    this.retries = options.retries ?? DEFAULT_RETRIES
    this.heartbeatInterval = options.heartbeatInterval ?? 0
    this.debug = options.debug ?? true
    this.onError = options.onError
    this.createId = options.createId ?? defaultCreateId
    this.unsubscribe = this.transport.onMessage((envelope) => this.receive(envelope))
    this.logState('会话创建')
  }

  get status(): SessionStatus {
    return this.statusValue
  }

  get stats(): SessionStats {
    return { ...this.counters }
  }

  /** 握手完成后调用：标记链路就绪并启动心跳 */
  markReady(): void {
    if (this.closed || this.statusValue === 'ready') return
    this.statusValue = 'ready'
    this.logState('会话就绪')
    this.startHeartbeat()
  }

  setDefaultTo(peer: PeerRef | '*'): void {
    this.defaultTo = peer
    this.logState('更新默认收件人')
  }

  /** 发事件（不关心对端处理结果） */
  emit(topic: string, payload?: unknown, options: SendOptions = {}): void {
    if (this.closed) return
    this.transmit(topic, payload, 'evt', options)
  }

  /** 发请求并等待响应 */
  request<R = unknown>(topic: string, payload?: unknown, options: RequestOptions = {}): Promise<R> {
    if (this.closed) {
      return Promise.reject(new ProtocolError(ProtocolErrorCode.Closed, '会话已关闭', { topic }))
    }
    const id = options.id ?? this.createId()
    const pending: PendingRequest = {
      id,
      topic,
      payload,
      target: options.to ?? this.defaultTo,
      idempotentKey: options.idempotentKey ?? id,
      attempt: 0,
      retries: options.retries ?? this.retries,
      baseTimeout: options.timeout ?? this.requestTimeout,
      startedAt: 0,
      resolve: () => undefined,
      reject: () => undefined,
      timer: undefined,
    }
    const promise = new Promise<R>((resolve, reject) => {
      pending.resolve = resolve as (value: unknown) => void
      pending.reject = reject
    })
    this.pending.set(id, pending)
    this.attempt(pending)
    return promise
  }

  /** 注册处理器；返回取消注册函数 */
  on(topic: string, handler: MessageHandler): () => void {
    const existing = this.handlers.get(topic)
    const set = existing ?? new Set<MessageHandler>()
    if (!existing) this.handlers.set(topic, set)
    set.add(handler)
    return () => {
      set.delete(handler)
      if (set.size === 0 && this.handlers.get(topic) === set) this.handlers.delete(topic)
    }
  }

  /** 是否有该 topic 的处理器 */
  handles(topic: string): boolean {
    const set = this.handlers.get(topic)
    return set !== undefined && set.size > 0
  }

  close(reason?: string): void {
    if (this.closed) return
    const wasActive = this.statusValue !== 'idle'
    this.closed = true
    this.statusValue = 'closed'
    this.stopHeartbeat()
    this.logState('会话关闭', { reason })

    if (wasActive) {
      try {
        this.transmit(Topics.SessionClose, reason === undefined ? undefined : { reason }, 'evt', {})
      } catch {
        // 链路已不可用时忽略关闭通知
      }
    }

    for (const pending of this.pending.values()) {
      this.clearTimer(pending)
      pending.reject(
        new ProtocolError(ProtocolErrorCode.Closed, `会话已关闭${reason ? `：${reason}` : ''}`, {
          topic: pending.topic,
          traceId: pending.id,
        }),
      )
    }
    this.pending.clear()
    this.handlers.clear()
    this.replyCache.clear()
    this.lastSeqs.clear()
    this.unsubscribe()
    this.transport.close()
  }

  // ── 内部实现 ──────────────────────────────────────────────────────

  private attempt(pending: PendingRequest): void {
    pending.attempt += 1
    pending.startedAt = Date.now()
    if (pending.attempt > 1) {
      this.counters.retries += 1
      this.logState('请求重试', {
        topic: pending.topic,
        id: pending.id,
        attempt: pending.attempt,
        maxAttempts: pending.retries + 1,
      })
    }

    const window = Math.min(pending.baseTimeout * 2 ** (pending.attempt - 1), MAX_TIMEOUT_WINDOW)
    this.transmit(pending.topic, pending.payload, 'req', {
      to: pending.target,
      id: pending.id,
      idempotentKey: pending.idempotentKey,
    })

    pending.timer = setTimeout(() => {
      if (!this.pending.has(pending.id)) return
      if (pending.attempt <= pending.retries) {
        this.attempt(pending)
        return
      }
      this.counters.timeouts += 1
      this.pending.delete(pending.id)
      this.logState('请求超时', {
        topic: pending.topic,
        id: pending.id,
        attempts: pending.attempt,
      })
      pending.reject(
        new ProtocolError(ProtocolErrorCode.Timeout, `请求超时：${pending.topic}`, {
          topic: pending.topic,
          traceId: pending.id,
        }),
      )
    }, window)
  }

  private transmit(topic: string, payload: unknown, kind: EnvelopeKind, options: SendOptions): Envelope {
    const envelope: Envelope = {
      v: this.version,
      id: options.id ?? this.createId(),
      seq: ++this.seqCounter,
      ts: Date.now(),
      from: this.self,
      to: options.to ?? this.defaultTo,
      kind,
      topic,
    }
    if (payload !== undefined) envelope.payload = payload
    if (options.idempotentKey !== undefined) envelope.idempotentKey = options.idempotentKey
    this.counters.sent += 1
    this.logMessage('发送', envelope)
    this.transport.send(envelope)
    return envelope
  }

  private receive(envelope: Envelope): void {
    if (this.closed) return
    this.counters.received += 1
    this.logMessage('接收', envelope)

    if (!envelope || !peerMatches(envelope.to, this.self) || samePeer(envelope.from, this.self)) {
      this.counters.dropped += 1
      this.logState('消息丢弃', { reason: '收件人不匹配或发送端点为自身' })
      return
    }
    // 用 peerMatches 而不是 samePeer：`acceptFrom` 允许只给 role
    // （子应用在 welcome 之前不知道宿主端点名），samePeer 要求 app 精确相等，
    // 结果是「只给了 role」的过滤器匹配不上任何真实对端，宿主发来的消息全被丢掉。
    if (this.acceptFrom !== '*' && !peerMatches(this.acceptFrom, envelope.from)) {
      this.counters.dropped += 1
      this.logState('消息丢弃', { reason: '发送端点不在 acceptFrom 范围内' })
      return
    }
    if (envelope.v !== this.version) {
      this.report(
        new ProtocolError(ProtocolErrorCode.NotSupported, `协议版本不匹配：本地 v${this.version} / 对端 v${envelope.v}`, {
          topic: envelope.topic,
          traceId: envelope.id,
        }),
      )
      this.logState('消息丢弃', { reason: '协议版本不匹配', localVersion: this.version, remoteVersion: envelope.v })
      return
    }

    const origin = `${envelope.from.app}:${envelope.from.role}`
    const lastSeq = this.lastSeqs.get(origin) ?? 0
    if (envelope.seq <= lastSeq) {
      this.counters.dropped += 1
      this.logState('消息丢弃', { reason: 'seq 重复或乱序', lastSeq, receivedSeq: envelope.seq })
      return
    }
    this.lastSeqs.set(origin, envelope.seq)

    if (envelope.topic === Topics.SessionPing) {
      this.lastPongAt = Date.now()
      this.logState('收到心跳请求', { id: envelope.id })
      this.transmit(Topics.SessionPong, envelope.payload, 'evt', { to: envelope.from })
      return
    }
    if (envelope.topic === Topics.SessionPong) {
      this.lastPongAt = Date.now()
      this.logState('收到心跳应答', { id: envelope.id })
      return
    }

    if (envelope.kind === 'res') {
      this.settle(envelope)
      return
    }
    if (envelope.kind === 'req') {
      void this.handleRequest(envelope)
      return
    }
    void this.handleEvent(envelope)
  }

  private settle(envelope: Envelope): void {
    const pending = this.pending.get(envelope.id)
    if (!pending) {
      this.logState('响应忽略', { topic: envelope.topic, id: envelope.id, reason: '没有匹配的请求' })
      return
    }
    this.clearTimer(pending)
    this.pending.delete(pending.id)
    this.counters.lastRttMs = Date.now() - pending.startedAt

    if (envelope.error) {
      this.logState('响应失败', {
        topic: pending.topic,
        id: pending.id,
        rttMs: this.counters.lastRttMs,
        error: envelope.error,
      })
      pending.reject(
        new ProtocolError(envelope.error.code, envelope.error.message, {
          topic: envelope.topic,
          traceId: envelope.id,
        }),
      )
      return
    }
    this.logState('响应成功', {
      topic: pending.topic,
      id: pending.id,
      rttMs: this.counters.lastRttMs,
    })
    pending.resolve(envelope.payload)
  }

  private async handleRequest(envelope: Envelope): Promise<void> {
    this.logState('开始处理请求', { topic: envelope.topic, id: envelope.id })
    const key = envelope.idempotentKey ?? envelope.id
    const cached = this.replyCache.get(key)
    if (cached) {
      this.logState('命中幂等缓存', { topic: envelope.topic, id: envelope.id, idempotentKey: key })
      this.respond(envelope, cached.payload, cached.error)
      return
    }

    const handlers = this.handlers.get(envelope.topic)
    if (!handlers || handlers.size === 0) {
      const error: EnvelopeErrorInfo = {
        code: ProtocolErrorCode.NotSupported,
        message: `未注册处理器：${envelope.topic}`,
      }
      this.remember(key, { payload: undefined, error })
      this.logState('请求无处理器', { topic: envelope.topic, id: envelope.id })
      this.respond(envelope, undefined, error)
      return
    }

    try {
      let result: unknown
      for (const handler of handlers) {
        result = await handler(envelope.payload, envelope)
      }
      // 不是给我的消息：不回 res、也不进幂等缓存，让真正的收件人去应答
      if (result === NO_REPLY) {
        this.logState('请求忽略', { topic: envelope.topic, id: envelope.id, reason: '处理器返回 NO_REPLY' })
        return
      }
      this.remember(key, { payload: result, error: undefined })
      this.logState('请求处理完成', { topic: envelope.topic, id: envelope.id })
      this.respond(envelope, result, undefined)
    } catch (error) {
      const protocolError = toProtocolError(error)
      const info: EnvelopeErrorInfo = { code: protocolError.code, message: protocolError.message }
      this.remember(key, { payload: undefined, error: info })
      this.logState('请求处理失败', { topic: envelope.topic, id: envelope.id, error: info })
      this.respond(envelope, undefined, info)
    }
  }

  private async handleEvent(envelope: Envelope): Promise<void> {
    const handlers = this.handlers.get(envelope.topic)
    if (!handlers || handlers.size === 0) {
      this.logState('事件无处理器', { topic: envelope.topic, id: envelope.id })
      return
    }
    this.logState('开始处理事件', { topic: envelope.topic, id: envelope.id })
    for (const handler of handlers) {
      try {
        await handler(envelope.payload, envelope)
      } catch (error) {
        this.report(toProtocolError(error))
      }
    }
    this.logState('事件处理完成', { topic: envelope.topic, id: envelope.id })
  }

  private respond(request: Envelope, payload: unknown, error: EnvelopeErrorInfo | undefined): void {
    const envelope: Envelope = {
      v: this.version,
      id: request.id,
      seq: ++this.seqCounter,
      ts: Date.now(),
      from: this.self,
      to: request.from,
      kind: 'res',
      topic: request.topic,
    }
    if (payload !== undefined) envelope.payload = payload
    if (error !== undefined) envelope.error = error
    this.counters.sent += 1
    this.logMessage('发送', envelope)
    this.transport.send(envelope)
  }

  private remember(key: string, reply: CachedReply): void {
    if (this.replyCache.size >= MAX_CACHED_REPLIES) {
      const oldest = this.replyCache.keys().next()
      if (!oldest.done) this.replyCache.delete(oldest.value)
    }
    this.replyCache.set(key, reply)
  }

  private startHeartbeat(): void {
    if (this.heartbeatInterval <= 0 || this.heartbeatTimer !== undefined) return
    this.lastPongAt = Date.now()
    this.heartbeatTimer = setInterval(() => {
      const silence = Date.now() - this.lastPongAt
      if (silence > this.heartbeatInterval * HEARTBEAT_MISS_FACTOR) {
        this.lastPongAt = Date.now()
        this.report(new ProtocolError(ProtocolErrorCode.Timeout, '心跳超时，链路可能已断开'))
        return
      }
      try {
        this.transmit(Topics.SessionPing, { at: Date.now() }, 'evt', {})
      } catch {
        // 链路暂时不可用，等下一个周期
      }
    }, this.heartbeatInterval)
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer === undefined) return
    clearInterval(this.heartbeatTimer)
    this.heartbeatTimer = undefined
  }

  private clearTimer(pending: PendingRequest): void {
    if (pending.timer === undefined) return
    clearTimeout(pending.timer)
    pending.timer = undefined
  }

  private report(error: ProtocolError): void {
    this.logState('协议错误', {
      code: error.code,
      message: error.message,
      topic: error.topic,
      traceId: error.traceId,
    })
    if (this.onError) this.onError(error)
  }

  private logMessage(direction: '发送' | '接收', envelope: Envelope | unknown): void {
    if (!this.debug || typeof console === 'undefined') return

    const message = envelope !== null && typeof envelope === 'object' ? (envelope as Record<string, unknown>) : {}
    const roleLabel = this.self.role === 'host' ? '主' : '子'
    const topic = typeof message.topic === 'string' ? message.topic : '<unknown>'
    const indent = this.self.role === 'sub' ? '    ' : ''

    // 字符串保持简短；完整信封作为第二个参数输出，浏览器控制台可折叠查看。
    console.log(
      `${indent}[@ut][${roleLabel}][${direction}] topic=${topic} role=${this.self.role} status=${this.statusValue}`,
      envelope,
    )
  }

  private logState(event: string, _details: Record<string, unknown> = {}): void {
    if (!this.debug || typeof console === 'undefined') return
    const roleLabel = this.self.role === 'host' ? '主' : '子'
    const indent = this.self.role === 'sub' ? '    ' : ''
    console.log(`${indent}[@ut][${roleLabel}][状态] ${event}`, {
      role: this.self.role,
      status: this.statusValue,
    })
  }
}
