import type { Envelope } from './envelope'

/**
 * 传输层抽象。
 *
 * 整个工程里 **只有 transport 实现文件可以 import wujie / postMessage**。
 * SDK 上层（Session、Container、业务回调）一律面向这个接口编程，
 * 于是"换传输方式"变成新增一个实现文件，而不是全量搜索替换。
 */
export type TransportMessageHandler = (envelope: Envelope) => void

export type TransportKind = 'wujie' | 'postMessage' | 'mf' | 'standalone' | 'memory'

export interface Transport {
  readonly kind: TransportKind
  /** 发送一封已构造好的信封 */
  send(envelope: Envelope): void
  /** 订阅入站消息，返回取消订阅函数 */
  onMessage(handler: TransportMessageHandler): () => void
  /** 关闭传输（释放监听、断开端口） */
  close(): void
}

/** memory 传输的投递入口：对端通过它把信封塞进本端 */
interface MemoryInbox {
  receive(envelope: Envelope): void
}

/**
 * 内存传输：同进程内主子应用直连，用于单元测试与"子应用脱离宿主单独开发"的联调场景。
 *
 * `kind` 可覆盖成 `'mf'`：MF 组件形态就是这条实现，两个端点在同一个 realm 里，
 * 差别只在 hello 里报的 `mode`。把它抽出来而不是另写一份，
 * 是为了让"测试用的假传输"和"生产用的 MF 传输"共用同一段投递逻辑 ——
 * 否则单测通过、上线丢消息。`createNullTransport` 早就是这个形状，这里补齐一致性。
 */
export function createMemoryTransport(kind: TransportKind = 'memory'): Transport & { connect(other: Transport): void } {
  const handlers = new Set<TransportMessageHandler>()
  let peer: Transport | null = null
  let closed = false

  function deliver(target: Transport, envelope: Envelope): void {
    ;(target as unknown as Partial<MemoryInbox>).receive?.(envelope)
  }

  const self: Transport & { connect(target: Transport): void } = {
    kind,
    send(envelope) {
      const target = peer
      if (closed || !target) return
      queueMicrotask(() => deliver(target, envelope))
    },
    onMessage(handler) {
      handlers.add(handler)
      return () => handlers.delete(handler)
    },
    close() {
      closed = true
      handlers.clear()
      peer = null
    },
    connect(target) {
      peer = target
    },
  }

  // 仅 memory 传输暴露的入站入口，供对端投递
  ;(self as unknown as MemoryInbox).receive = (envelope) => {
    if (closed) return
    for (const handler of handlers) handler(envelope)
  }

  return self
}

/**
 * 事件总线的最小接口（wujie 的 eventBus、自研 bus 都满足）。
 *
 * 放在 protocol 而不是各端 SDK 里，是为了让主子两端的传输实现
 * 共享同一个"总线形状"定义，避免各写一份结构体导致 `$off` 签名对不上。
 */
export interface EventBusLike {
  $on(eventName: string, handler: (payload: unknown) => void): void
  $emit(eventName: string, payload: unknown): void
  $off(eventName: string, handler: (payload: unknown) => void): void
}

/**
 * 空传输：没有宿主（子应用单独运行）或没有总线（宿主没装 wujie）时用它兜底。
 *
 * 关键语义是 **不抛异常** —— 上层照常跑，只是收不到对端消息。
 * 抛异常会让"子应用脱离宿主单独开 dev server"这种正常场景白屏。
 */
export function createNullTransport(kind: TransportKind = 'standalone'): Transport {
  return {
    kind,
    send() {
      // 无对端，丢弃
    },
    onMessage() {
      return () => undefined
    },
    close() {
      // 无需清理
    },
  }
}
