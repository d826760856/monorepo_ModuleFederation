/**
 * 能力配置的公共词表。
 *
 * 详情配置（`detail.ts`）与功能配置（`feature.ts`）是两张**独立的表**，走两个端点，
 * 只有这几个枚举与非空校验规则共用。放在这里而不是塞进任一方的文件里，
 * 是因为任何一方都不该拥有另一方需要的词。
 */

/**
 * 保活策略。
 * - none：卸载即销毁
 * - snapshot：保留实例，但只用本地缓存渲染，不维持通信（省资源）
 * - live：保留实例并维持通信链路（切换回来要立刻是热的）
 */
export type CacheMode = 'none' | 'snapshot' | 'live'

/** 可见人群，用于灰度与白名单 */
export type Audience = 'all' | 'internal' | 'beta'

/**
 * 展开形态（只有功能模块有这个概念）。
 *
 * 详情页是整页承载，不存在"嵌在哪个容器里"；把它塞进详情配置，
 * 等于让子应用去声明宿主的呈现方式。
 */
export type PanelMode = 'inline' | 'drawer' | 'modal'

/**
 * 功能模块按工单字段做的二次过滤。
 *
 * 例如「小区状态」只对 `网元类型=小区` 的工单显示。
 * 这是**唯一**允许按工单状态/字段筛功能模块的入口：
 * 工单状态属于运行时数据，写进配置只会在数据变化后过期。
 */
export interface FeatureOrderMatch {
  /** 快照字段的 key（优先）或 label */
  field: string
  /** 该字段不存在时是否算命中；默认 false */
  exists?: boolean
  /** 字段值必须落在其中之一 */
  in?: readonly string[]
}

/** 配置项的身份与运维字段，两类配置共用 */
export interface ConfigMeta {
  /** 功能唯一 id，例如 alert-order.detail */
  id: string
  /** 展示名 */
  name: string
  /** 描述，用于管理端展示 */
  description?: string
  /** 展示优先级，数字小的靠前 */
  priority?: number
  audience?: Audience
  /** 生效环境，例如 ['dev','test'] */
  envs?: readonly string[]
  /** 备注：接入方自查用 */
  owner?: string
}

/**
 * 配置服务响应信封。
 *
 * 两张表各有一个实例，各自的 `version` / `updatedAt` / ETag 独立 ——
 * 一次功能配置的改动不该让详情配置的缓存失效。
 */
export interface ConfigResponse<TItem> {
  version: string
  updatedAt: number
  items: readonly TItem[]
}
