/**
 * 能力配置模型。
 *
 * 两张独立的表、两个端点、两套类型：
 * - `DetailConfig`  —— 怎么把一个系统的**详情整页**嵌进来（wujie）
 * - `FeatureConfig` —— 工单详情里能开哪些**关联功能**（MF 组件）
 *
 * 不共用一个判别联合：配置端从来就是分两份写的，合成一份只是为了省一个
 * HTTP 请求，代价是逼出一个顶层判别字段，以及一方的坏数据拖垮另一方。
 */
export * from './common'
export * from './detail'
export * from './feature'
