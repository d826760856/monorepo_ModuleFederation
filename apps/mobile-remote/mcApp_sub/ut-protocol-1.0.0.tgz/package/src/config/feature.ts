import type { ConfigMeta, ConfigResponse, FeatureOrderMatch, PanelMode } from './common'

/** 关联功能模块的组件入口（MF 远程模块坐标） */
export interface FeatureModuleEntry {
  /** MF 远程模块，例如 alert-order */
  remote: string
  /** 暴露的模块名，例如 ./Feature */
  exposed: string
}

/**
 * 一条**关联功能模块**配置。
 *
 * 关键区别：功能模块**不是**详情载体，它是工单详情页里的一个功能区块
 * （「小区状态 / 基站状态 / 附近故障……」列表项）。工单数据由详情载体
 * 上报宿主，宿主再把同一份视图分发给所有功能模块 —— 所以这里没有
 * 「我怎么取工单数据」的位置。
 *
 * 与详情配置拆成两张表、两个端点：两者的查询维度、失败后果、更新节奏都不同。
 * 一张表混排时会逼出一个顶层判别字段，而配置端从来就是分两份写的。
 */
export interface FeatureConfig extends ConfigMeta {
  /** 列表项图标（URL 或图标名，由宿主决定怎么渲染） */
  icon?: string
  /** 提供该功能模块的子应用名，必须与组件握手时的 appName 一致 */
  appName: string
  /**
   * 在哪些**工单类别**下出现（alert / complaint / fault…）。
   *
   * 只放类别，不放来源菜单 stage（todo / pendingAcceptance / done…）或业务状态：
   * 它们都是运行时数据，写进配置后会在状态流转或菜单切换时立刻过期。
   * 需要按状态或其它字段筛时，一律走 `orderMatch`。
   *
   * 空数组视为配置错误（永远筛不中），由投影侧的校验拦下。
   */
  orderTypes: readonly string[]
  /** 细筛：按工单字段过滤（可选） */
  orderMatch?: FeatureOrderMatch
  entry: FeatureModuleEntry
  /** 点开后的展开形态 */
  panel: PanelMode
}

/** 功能配置端点响应（GET /api/capabilities/features） */
export type FeatureConfigResponse = ConfigResponse<FeatureConfig>
