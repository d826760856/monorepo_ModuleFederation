import type { PlatformKind } from '../models'
import type { CacheMode, ConfigMeta, ConfigResponse } from './common'

/** 整页详情入口的地址描述 */
export interface DetailEntry {
  /** 子系统入口 URL（单端系统只填这个） */
  url: string
  /**
   * 双端系统分别给地址；缺哪端就回落到 `url`。
   *
   * 各系统 PC / App 侧是隔离的两套 UI，不能拿一端地址顶另一端，
   * 所以宁可在这里显式声明，也不要在宿主侧做「猜一个」的降级。
   */
  platformUrls?: Partial<Record<PlatformKind, string>>
  /** 宿主路由片段，例如 /detail/:todoId */
  route?: string
}

/**
 * 一条**整页详情**配置。
 *
 * 这份配置只回答一个问题：**怎么把一个系统的详情页嵌进来**。
 * 因此它不含任何工单概念：
 * - 「这条待办归哪个系统」由 `TodoSource.match` 在列表层回答，输入是待办记录本身；
 * - 「这是哪类工单」是**这一条待办**的属性，来自路由而不是配置。
 *
 * 放进来的每一个字段都必须有消费者，否则就是配置说了不算的假数据。
 */
export interface DetailConfig extends ConfigMeta {
  /** 提供详情页的子应用名（必须与握手时的 appName 一致），同时作为 `TodoSource.key` */
  appName: string
  entry: DetailEntry
  cacheMode: CacheMode
}

/** 详情配置端点响应（GET /api/capabilities/details） */
export type DetailConfigResponse = ConfigResponse<DetailConfig>
