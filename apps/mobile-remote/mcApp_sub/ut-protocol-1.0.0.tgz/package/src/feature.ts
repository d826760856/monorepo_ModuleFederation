import { PROTOCOL_VERSION } from './envelope'
import type { Envelope } from './envelope'
import type { Transport, TransportKind, TransportMessageHandler } from './transport'

/**
 * MF 组件形态的传输桥。
 *
 * 为什么可以不经 postMessage：远程模块被 `loadRemote()` 加载后，
 * 组件函数和宿主代码跑在**同一个 window、同一个事件循环**里，
 * 函数可以直接传 —— 没有跨 frame，也就没有序列化。
 *
 * 代价必须写在明面上：同 realm 意味着 **MF 组件不是安全边界**。
 * 组件能读到宿主的 window / token / 全局 store，也能改宿主的 DOM 与路由。
 * 所以这条通道只给"同交付范围（同团队、同发布节奏、同信任等级）"的子系统用，
 * 第三方、外部厂商一律走 wujie 的 iframe 沙箱。
 *
 * 语义与 `Transport` 完全一致，只是去掉了 kind/close：
 * 生命周期归宿主那侧的组件管，子组件不该有能力关掉半条链。
 */
export interface FeatureBridge {
  /**
   * 投递一封已构造好的信封。
   *
   * 实现**必须**是异步投递（下一次微任务），不能同步调对端 handler。三个原因：
   * 1. 子组件挂载即发 hello，同步投递会在宿主监听注册完成之前到达 → 握手丢失；
   * 2. 一条 req 触发 res、res 再触发 evt，同步会叠成几百层调用栈；
   * 3. `Session.request()` 依赖"先返回 Promise，再收到 res"的时序假设。
   */
  send(envelope: Envelope): void
  /** 订阅入站消息，返回取消订阅函数 */
  subscribe(handler: TransportMessageHandler): () => void
}

/**
 * 把宿主经 props 传下来的 bridge 适配成标准 `Transport`。
 *
 * 有它，`Session` 完全不需要知道自己是跑在 wujie 总线上还是 MF 桥上 ——
 * 这也是"换传输不换协议"能成立的那一行。
 */
export function bridgeToTransport(bridge: FeatureBridge, kind: TransportKind = 'mf'): Transport {
  return {
    kind,
    send: (envelope) => bridge.send(envelope),
    onMessage: (handler) => bridge.subscribe(handler),
    /** 由组件卸载统一收口，桥本身没有可释放的端口 */
    close: () => undefined,
  }
}

/** 组件形态约定的暴露名：业务组件 */
export const FEATURE_EXPOSE = './Feature'
/** 组件形态约定的暴露名：版本元信息（只含常量，加载极轻） */
export const FEATURE_META_EXPOSE = './meta'

/**
 * 组件形态的入参契约（宿主传给远程组件的 props）。
 *
 * 放在 protocol 而不是各端 SDK 里：宿主（micro-app）要按它渲染，
 * 子组件（@ut/sub-mf）要按它接收，两边必须同一个定义 ——
 * 否则宿主多传一个、子端少收一个，类型检查全绿、运行时静默失效。
 *
 * 只有这两项，业务数据一律不许走 props：
 * props 会随宿主重渲染而变，而会话上下文是**工单级**的，
 * 走 props 就等于允许两套上下文并存（这正是"保活串数据"的成因）。
 */
export interface FeatureBridgeProps {
  /** 宿主造好的桥；必须稳定（宿主侧 useMemo/useRef 持有） */
  bridge: FeatureBridge
  /** 实例身份，`<appName>_<业务主键>`；同一子应用的多个工单靠它分开 */
  instanceId: string
  /**
   * 功能模块 id（配置里 `FeatureConfig.id`）。
   *
   * 宿主知道自己挂的是哪一条配置，模块自己不知道 —— 上报数据（`feature.data`）
   * 时靠它区分「小区状态」和「基站状态」。由宿主注入，不给模块留手填的口子。
   */
  moduleId?: string
}

/**
 * 组件形态自报的版本元信息。
 *
 * 单独暴露一份 `./meta` 而不是从组件里读，是为了让宿主在**加载组件之前**
 * 就能判断版本是否兼容：不兼容直接给升级提示，
 * 而不是把组件整包拉下来、再等 30s 握手超时才知道对不上。
 */
export interface FeatureMeta {
  /** 远程应用名，必须等于宿主配置里的 appName */
  appName: string
  /** 协议版本，取自 `@ut/protocol` 的 `PROTOCOL_VERSION` */
  protocolVersion: number
  /** 构建时间戳（ms），排障用 */
  buildTime?: number
  /** 构建 commit，排障用 */
  commit?: string
}

/** 版本是否兼容。当前策略：主版本相等即可（协议只在破坏性变更时递增）。 */
export function isFeatureMetaCompatible(meta: FeatureMeta, expected = PROTOCOL_VERSION): boolean {
  return meta.protocolVersion === expected
}
