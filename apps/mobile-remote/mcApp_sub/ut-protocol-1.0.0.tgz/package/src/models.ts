import type { Surface } from './envelope'

/**
 * 工单上下文。
 *
 * 关键约束：**工单级**，不是全局的。宿主每进一个工单就构造一份并通过 `order.data` 下发；
 * 子应用不允许把它缓存成模块级单例 —— 这正是“保活串数据”bug 的根源。
 */
export interface WorkOrderContext {
  orderId?: string
  orderType?: string
  tenantId?: string
  productId?: string
  /** 来源渠道，例如 mobile / pc */
  source?: string
  /** 宿主允许子应用读取的 UI 上下文（主题、语言、安全区等），结构由宿主决定 */
  ui?: Readonly<Record<string, unknown>>
  /** 该工单开启的特性开关 */
  features?: readonly string[]
}

/**
 * 宿主拉取工单快照时随请求携带的上下文。
 *
 * `welcome` 与会话层的 `ready` 不是同一次投递：宿主 resolve ready 时，welcome
 * 响应可能还没送到子应用。若 `order.get` 只依赖此前收到的 welcome，子应用首屏
 * 就可能用空上下文调用 `getOrderSnapshot`。请求自身带上上下文后，首屏不再依赖
 * 两条消息的到达顺序。
 */
export interface OrderGetPayload {
  context: WorkOrderContext
}

/** 详情页的只读字段。条数不设上限，纯展示、不可点击。 */
export interface OrderField {
  key?: string
  label: string
  value: string
}

/** 操作按钮描述 */
export interface ActionDescriptor {
  key: string
  label: string
  primary?: boolean
  icon?: string
  disabled?: boolean
  /** 宿主可透传的参数，点击时原样回传给子应用 */
  args?: unknown
}

/**
 * 移动端宿主会按来源菜单 stage 自动补充的默认按钮。
 * 子应用仍需要在 `onAction` 中实现这些 key 对应的业务操作。
 *
 * stage 表示列表来源菜单，不是快照里的业务状态：
 * pendingAcceptance（待接单）尚未接单，展示“立即接单”；
 * todo（待办）已经接单、等待处理，展示“转派/暂存/返单”。
 */
export const MOBILE_DEFAULT_ACTIONS_BY_STATUS = {
  pendingAcceptance: [
    { key: 'accept-now', label: '立即接单', primary: true },
  ],
  todo: [
    { key: 'reassign', label: '转派', primary: false },
    { key: 'save', label: '暂存', primary: false },
    { key: 'return', label: '返单', primary: true },
  ],
} as const satisfies Readonly<Partial<Record<
  'pendingAcceptance' | 'todo' | 'done' | 'unread' | 'read' | 'initiatedByMe',
  readonly ActionDescriptor[]
>>>

export type MobileDefaultActionKey =
  (typeof MOBILE_DEFAULT_ACTIONS_BY_STATUS)[keyof typeof MOBILE_DEFAULT_ACTIONS_BY_STATUS][number]['key']

/** 动作 key 既可以是宿主默认按钮，也可以是子应用自定义按钮。 */
export type ActionKey = MobileDefaultActionKey | (string & {})

/**
 * 子应用接入时可以返回的简化快照。
 *
 * 这是 `@ut/sub-sdk` 的业务输入格式；协议层会把它补成 `OrderSnapshot`。
 */
export interface EntryOrderSnapshot {
  orderId: string
  updatedAt: number
  status?: string
  title?: string
  creator?: string
  actions?: readonly ActionDescriptor[]
}

/**
 * 工单快照：**子应用拥有的一份数据**。
 *
 * 子应用可以直接返回 `EntryOrderSnapshot`，由 SDK 封装为这里的完整格式；
 * 也可以直接返回完整协议快照。宿主通过 `order.get` 拉取、或通过 `order.data` 接收。
 */
export interface OrderSnapshot extends EntryOrderSnapshot {
  /** 详情页状态展示文案；完整快照可选。 */
  statusText?: string
  /** 自定义详情字段；简化快照由 SDK 根据 orderId / creator 自动补齐。 */
  fields?: readonly OrderField[]
}

/**
 * 工单视图：宿主投影给**功能模块**的只读切片。
 *
 * 视图只暴露与 `EntryOrderSnapshot` 同构的工单字段，并补充 `orderType`
 * 和 `ready`。详情页专属的 `actions`、展示文案 `statusText` 及明细
 * `fields` 不进入功能模块契约；`ready` 用于区分「详情还没上报」和空数据。
 */
export interface OrderView extends Omit<EntryOrderSnapshot, 'actions'> {
  orderType: string
  /** false = 详情载体还没上报过，模块应显示空态而不是报错 */
  ready: boolean
}

/**
 * 把子应用简化快照封装成协议快照。
 *
 * `fields` 已存在时保留原字段；缺少 `creator` 时从常见提单人字段回填，
 * 这样详情页和 MF 功能模块都可以直接使用统一的 `creator` 字段。
 */
export function normalizeOrderSnapshot(snapshot: EntryOrderSnapshot | OrderSnapshot): OrderSnapshot {
  const protocolSnapshot = snapshot as OrderSnapshot
  if (protocolSnapshot.fields !== undefined) {
    return {
      ...protocolSnapshot,
      creator: protocolSnapshot.creator ?? findCreator(protocolSnapshot.fields),
    }
  }

  return {
    orderId: snapshot.orderId,
    updatedAt: snapshot.updatedAt,
    status: snapshot.status,
    statusText: protocolSnapshot.statusText,
    title: snapshot.title,
    creator: snapshot.creator,
    fields: [
      { key: 'orderId', label: '工单编号', value: snapshot.orderId },
      { key: 'creator', label: '提单人', value: snapshot.creator ?? '' },
    ],
    actions: snapshot.actions,
  }
}

function findCreator(fields: readonly OrderField[]): string | undefined {
  const field = fields.find(
    (item) =>
      item.key === 'creator' ||
      item.key === '提单人' ||
      item.key === '发起人' ||
      item.key === '处理人' ||
      item.label === 'creator' ||
      item.label === '提单人' ||
      item.label === '发起人' ||
      item.label === '处理人',
  )
  return field?.value
}

/**
 * 功能模块 → 宿主的**部分数据**上报。
 *
 * `moduleId` / `orderId` / `at` 由 SDK 自动补，模块只填业务内容 ——
 * 强制回带 `orderId` 是为了让宿主能校验归属（防串单），
 * `at` 用于去旧（同一模块的旧结果不该覆盖新结果）。
 *
 * 宿主不解释 `data` 的语义，只按 `moduleId` 存取；`summary` 是给宿主列表角标
 * 直接用的短文本，避免宿主为了显示一行摘要去理解模块的私有结构。
 */
export interface FeatureReport {
  /** 哪个功能模块（SDK 补） */
  moduleId: string
  /** 归属工单（SDK 从上下文补，宿主校验） */
  orderId: string
  /** 上报时刻（SDK 补，宿主去旧） */
  at: number
  /** 一句话摘要，宿主可直接用于列表副标题 / 角标 */
  summary?: string
  /** 模块自定义结果，宿主原样保存 */
  data?: unknown
  /** 可选的种类标记，便于宿主按种类分流（不做语义解释） */
  kind?: string
}

/** 按钮点击请求 */
export interface ActionInvokePayload {
  /**
   * 移动端宿主默认 key：`reassign`、`save`、`return`、`accept-now`；
   * 其它值表示子应用在快照 `actions` 中声明的自定义按钮。
   */
  key: ActionKey
  args?: unknown
}

/** 按钮点击结果 */
export interface ActionResult {
  ok: boolean
  message?: string
}

/** 取消一条订阅（子应用在条目失效时主动回收） */
export interface SubscriptionCancelPayload {
  subId: string
}

/** 上下文增量更新：子应用 → 宿主（例如切换了 tab、改变了查询条件，需要宿主同步地址栏） */
export type ContextUpdatePayload = Partial<WorkOrderContext>

/** 轻提示 */
export interface NotifyToastPayload {
  message: string
  level?: 'info' | 'success' | 'warn' | 'error'
  duration?: number
}

/** 请求宿主跳转（子应用不直接操作宿主路由） */
export interface NotifyNavigatePayload {
  /** 宿主内部路由，例如 `/todos/:id` 或 `back` */
  route: string
  /** 需要携带的参数 */
  params?: Readonly<Record<string, string>>
}

/**
 * 订阅条目状态。
 * snapshot = 只有静态快照（首屏由列表数据直接渲染，没有拉通实时链路）
 * live = 已建立实时通道，后续风险提示会推翻快照
 */
export type SubscriptionStatus = 'snapshot' | 'live'

/** 订阅（待办列表里的一条） */
export interface SubscriptionItem {
  /** 订阅唯一标识，用于取消订阅 */
  subId: string
  /** 提供该条目的子应用名 */
  appName: string
  /** 实体类型，例如 order / risk */
  entityType: string
  /** 业务主键（不是待办 id），用于回源查询 */
  businessKey: string
  orderId: string
  title: string
  tag?: string
  summary?: string
  data?: unknown
  status: SubscriptionStatus
  updatedAt: number
  /** 单调递增版本号，宿主据此丢弃过期消息 */
  version?: number
}

/**
 * 握手：子应用 → 宿主（广播，因为此时还不知道宿主名）。
 *
 * `appName` 是应用身份，必须等于宿主配置的 `remoteAppName` —— 宿主靠它过滤；
 * `instanceId` 是实例身份，缺省时宿主回落成"按 app 过滤"（单实例场景够用，
 * 但同时打开两个工单就会串上下文，所以能传一定要传）。
 */
export interface HelloPayload {
  appName: string
  /** 实例身份，通常等于 wujie 实例名（`<appName>_<业务主键>`），由宿主经 props 注入 */
  instanceId?: string
  protocolVersion?: number
  /** 子应用被嵌入的方式 */
  mode?: 'wujie' | 'mf' | 'standalone' | 'memory'
  /**
   * 这个子应用扮演的承载面。
   *
   * `detail` 提供工单快照（应答 `order.get`），`feature` 消费工单视图（接收 `order.view`）。
   * 宿主据此在握手阶段就挡掉"把 detail 应用挂在 feature 槽位"这类配置错误 ——
   * 没有它，这种错只能表现为 30 秒握手超时。
   */
  surface?: Surface
}

/** 握手：宿主 → 子应用 */
export interface WelcomePayload {
  hostName: string
  /** 宿主侧实例身份，子应用据此把后续消息精确投递给本宿主 */
  instanceId?: string
  protocolVersion: number
  /** 心跳间隔（ms），0 表示不启用 */
  heartbeatInterval?: number
  /**
   * 工单上下文。
   * 必须随 welcome 一起下发 —— 子应用详情页的业务起点就是它，
   * 少一次往返，也避免子应用在拿到上下文前先渲染一版空状态。
   */
  context: WorkOrderContext
}

/** 运行平台 */
export type PlatformKind = 'mobile' | 'pc'

/** 视口信息（宿主采集后通过 ui 上下文下发，子应用据此自适应） */
export interface Viewport {
  width: number
  height: number
  /** 安全区，单位 px */
  safeArea?: { top: number; right: number; bottom: number; left: number }
}

/** 平台能力描述 */
export interface PlatformProfile {
  kind: PlatformKind
  viewport: Viewport
  /** 是否支持 hover（PC 常用） */
  hoverable: boolean
}
