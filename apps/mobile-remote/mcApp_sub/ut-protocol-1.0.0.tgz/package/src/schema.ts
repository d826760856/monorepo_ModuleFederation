import { PROTOCOL_VERSION, type Envelope } from './envelope'
import { isKnownTopic, lookupTopic } from './topics'
import type { ActionInvokePayload, HelloPayload, OrderSnapshot, SubscriptionItem, WelcomePayload } from './models'

export interface ValidationIssue {
  field: string
  message: string
}

export type ValidationResult = { ok: true } | { ok: false; issues: readonly ValidationIssue[] }

const PASS: ValidationResult = { ok: true }

function fail(field: string, message: string): ValidationResult {
  return { ok: false, issues: [{ field, message }] }
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function nonEmptyString(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0
}

/**
 * 信封结构校验。
 *
 * 校验发生在**进站的第一步**，不合格的信封直接丢弃并计数（session.stats.dropped），
 * 而不是让它在业务代码里以 undefined 的形式炸开。
 */
export function validateEnvelope(raw: unknown): ValidationResult {
  if (!isRecord(raw)) return fail('envelope', '必须是对象')
  if (typeof raw.v !== 'number') return fail('v', '缺少协议版本')
  if (raw.v !== PROTOCOL_VERSION) return fail('v', `协议版本不匹配：收到 v${String(raw.v)}，期望 v${PROTOCOL_VERSION}`)
  if (!nonEmptyString(raw.id)) return fail('id', '缺少消息 id')
  if (typeof raw.seq !== 'number' || raw.seq <= 0) return fail('seq', 'seq 必须是正整数')
  if (typeof raw.ts !== 'number') return fail('ts', '缺少时间戳')
  if (!isRecord(raw.from) || !nonEmptyString(raw.from.app)) return fail('from', '缺少来源端点')
  if (raw.from.role !== 'host' && raw.from.role !== 'sub') return fail('from.role', '必须是 host 或 sub')
  if (raw.to !== '*' && !(isRecord(raw.to) && nonEmptyString(raw.to.app))) return fail('to', '必须是端点或 *')
  if (raw.kind !== 'req' && raw.kind !== 'res' && raw.kind !== 'evt') return fail('kind', '必须是 req / res / evt')
  if (!nonEmptyString(raw.topic)) return fail('topic', '缺少 topic')
  if (!isKnownTopic(raw.topic)) return fail('topic', `未在语义目录登记的 topic：${raw.topic}`)
  if (raw.kind === 'res' && raw.idempotentKey !== undefined && raw.error !== undefined) {
    return fail('error', '错误响应不应带幂等键')
  }
  return PASS
}

/** 入站解析：不合格直接返回 null，调用方据此丢弃 */
export function parseEnvelope(raw: unknown): Envelope | null {
  return validateEnvelope(raw).ok ? (raw as Envelope) : null
}

function validateHello(payload: unknown): ValidationResult {
  if (!isRecord(payload)) return fail('payload', 'hello 必须是对象')
  if (!nonEmptyString(payload.appName)) return fail('payload.appName', '缺少子应用名')
  if (payload.surface !== undefined && payload.surface !== 'detail' && payload.surface !== 'feature') {
    return fail('payload.surface', '必须是 detail 或 feature')
  }
  return PASS
}

function validateWelcome(payload: unknown): ValidationResult {
  if (!isRecord(payload)) return fail('payload', 'welcome 必须是对象')
  if (!nonEmptyString(payload.hostName)) return fail('payload.hostName', '缺少宿主名')
  if (!isRecord(payload.context)) return fail('payload.context', '缺少工单上下文')
  return PASS
}

function validateActionInvoke(payload: unknown): ValidationResult {
  const value = payload as ActionInvokePayload | undefined
  if (!value || !nonEmptyString(value.key)) return fail('payload.key', '缺少按钮 key')
  return PASS
}

function validateOrderGet(payload: unknown): ValidationResult {
  // 允许省略 payload，兼容尚未携带上下文的旧宿主。
  if (payload === undefined) return PASS
  if (!isRecord(payload)) return fail('payload', 'order.get 必须是对象')
  if (!isRecord(payload.context)) return fail('payload.context', '缺少工单上下文')
  return PASS
}

function validateOrderSnapshot(payload: unknown): ValidationResult {
  const value = payload as OrderSnapshot | undefined
  if (!value) return fail('payload', '缺少工单快照')
  if (!nonEmptyString(value.orderId)) return fail('payload.orderId', '缺少 orderId')
  if (typeof value.updatedAt !== 'number') return fail('payload.updatedAt', '缺少 updatedAt')
  if (value.creator !== undefined && typeof value.creator !== 'string') return fail('payload.creator', '必须是字符串')
  if (value.fields !== undefined && !Array.isArray(value.fields)) return fail('payload.fields', '必须是数组')
  return PASS
}

function validateSubscription(payload: unknown): ValidationResult {
  const value = payload as SubscriptionItem | undefined
  if (!value) return fail('payload', '缺少订阅条目')
  if (!nonEmptyString(value.subId)) return fail('payload.subId', '缺少 subId')
  if (!nonEmptyString(value.appName)) return fail('payload.appName', '缺少 appName')
  if (!nonEmptyString(value.orderId)) return fail('payload.orderId', '缺少 orderId')
  if (value.status !== 'snapshot' && value.status !== 'live') return fail('payload.status', '必须是 snapshot 或 live')
  return PASS
}

/**
 * 按 topic 校验 payload。
 *
 * 只校验“接入方容易写错且错了会静默失败”的字段，不做完整 JSON Schema —— 目的是让错误尽早、
 * 带字段名地暴露出来，而不是把协议变成负担。
 */
export function validatePayload(topic: string, payload: unknown): ValidationResult {
  const spec = lookupTopic(topic)
  if (!spec) return fail('topic', `未在语义目录登记的 topic：${topic}`)
  switch (topic) {
    case 'session.hello':
      return validateHello(payload)
    case 'session.welcome':
      return validateWelcome(payload)
    case 'action.invoke':
      return validateActionInvoke(payload)
    case 'order.get':
      return validateOrderGet(payload)
    case 'order.data':
      return validateOrderSnapshot(payload)
    case 'order.stream':
    case 'subscription.cancel':
      return validateSubscription(payload)
    default:
      return PASS
  }
}

export type { HelloPayload, WelcomePayload }
