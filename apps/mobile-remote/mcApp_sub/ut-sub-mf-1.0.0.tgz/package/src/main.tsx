import { createContext, createElement, useContext, useEffect, useState, useSyncExternalStore } from 'react'
import type { ComponentType, ReactNode } from 'react'
import { ProtocolError, ProtocolErrorCode, bridgeToTransport } from '@ut/protocol'
import type {
  FeatureBridgeProps,
  OrderView,
  WorkOrderContext,
} from '@ut/protocol'
import { createFeatureApp } from '@ut/sub-sdk'
import type {
  EntryAppNotifier,
  EntryAppState,
  EntryAppStatus,
  FeatureApp,
  FeatureAppOptions,
  FeatureReportInput,
} from '@ut/sub-sdk'

/**
 * 功能组件（MF）形态的子应用接入契约。
 *
 * 在 `FeatureAppOptions` 之上只多两件事：显示名、业务组件。
 * 协议侧的一切（身份、会话、能力、降级）与整页形态共用同一台机器，
 * 但**契约本身不共用** —— 功能模块没有 `getOrderSnapshot` / `onAction`，
 * 它不拥有工单数据，宿主也不会把 `order.get` 发到这里。
 */
export interface FeatureComponentOptions extends FeatureAppOptions {
  /** 组件显示名，仅用于 React DevTools 与报错信息 */
  displayName?: string
  /**
   * 子应用自己的业务组件。
   *
   * 它通过下面的 hooks 取上下文与数据，**不接收业务 props**：
   * 宿主只传 `bridge` + `instanceId` + `moduleId`，业务数据一律走协议
   * （工单数据：宿主经 `order.view` 广播）。
   */
  Component: ComponentType
}

/** 宿主渲染远程组件时传的 props（类型定义在 protocol，两端共用一份） */
export type FeatureHostProps = FeatureBridgeProps

/** 子应用业务代码通过它向宿主说话（上报数据、发提示、报上下文变化） */
export interface FeatureApi {
  readonly appName: string
  readonly instanceId: string | undefined
  readonly status: EntryAppStatus
  readonly hostName: string | undefined
  readonly protocolVersion: number
  readonly context: WorkOrderContext | undefined
  /** 宿主广播的工单视图（组件形态的工单数据入口） */
  readonly orderView: OrderView | undefined
  readonly notify: EntryAppNotifier
  /** 上报本模块那部分数据（宿主只存不解释） */
  reportFeature(report: FeatureReportInput): void
  /** 报告上下文变化，宿主据此同步地址栏 */
  updateContext(patch: Partial<WorkOrderContext>): void
}

interface FeatureStore {
  readonly api: FeatureApi
  start(): void
  /** 真正的销毁；组件卸载时延迟执行，见 `scheduleDispose` */
  dispose(): void
  /** 挂载/重挂载时取消延迟销毁（StrictMode 下 effect 会跑两遍） */
  cancelDispose(): void
  scheduleDispose(): void
  subscribe(listener: () => void): () => void
  getState(): EntryAppState
  getServerState(): EntryAppState
  /** 工单视图：引用只在宿主真的广播新数据时变，供 useSyncExternalStore 比较 */
  getOrderView(): OrderView | undefined
}

const CONNECTING_STATE: EntryAppState = {
  status: 'connecting',
  appName: '',
  instanceId: undefined,
  hostName: undefined,
  protocolVersion: 0,
  context: undefined,
  orderView: undefined,
  reason: undefined,
  error: undefined,
}

/** SSR / 首帧占位：快照还没有，返回同一个 undefined 保证引用稳定 */
const getUndefinedSnapshot = (): undefined => undefined

function isValidBridge(bridge: unknown): bridge is { send: (envelope: unknown) => void; subscribe: (handler: (envelope: unknown) => void) => () => void } {
  const candidate = bridge as { send?: unknown; subscribe?: unknown } | undefined
  return typeof candidate?.send === 'function' && typeof candidate.subscribe === 'function'
}

/**
 * 会话状态仓。
 *
 * 为什么不把 `FeatureApp` 直接丢进 React state：
 * `FeatureApp` 是有生命周期的命令式对象（定时器、监听、重试），
 * 放进 state 会让"读状态"和"改状态"混在一起，
 * 组件重渲染时还可能被误当成新对象重建，表现为"按钮点了没反应"。
 * 这里让命令式对象留在 store 里，React 只订阅它的快照。
 */
function createFeatureStore(options: FeatureComponentOptions, props: FeatureHostProps): FeatureStore {
  const listeners = new Set<() => void>()

  const emit = (): void => {
    for (const listener of listeners) listener()
  }

  const app: FeatureApp = createFeatureApp(
    {
      ...options,
      // 模块 id 归宿主：宿主知道挂的是哪一条配置，模块自己不知道
      moduleId: options.moduleId ?? props.moduleId,
      transport: bridgeToTransport(props.bridge),
      onStateChange: (state) => {
        options.onStateChange?.(state)
        emit()
      },
    },
    // 组件形态：hello 由 effect 里的 start() 发出，render 期不产生副作用
    { instanceId: props.instanceId, deferHandshake: true },
  )

  let cachedState: EntryAppState = { ...app.state, appName: options.appName, instanceId: props.instanceId }
  const serverState: EntryAppState = { ...cachedState }
  let cachedView: OrderView | undefined
  let disposed = false
  let disposeTimer: ReturnType<typeof setTimeout> | undefined

  const onState = (state: EntryAppState): void => {
    // 同一个对象只在变化时替换，供 useSyncExternalStore 做引用比较
    cachedState = state
    emit()
  }
  app.subscribe(onState)

  const api: FeatureApi = {
    get appName() {
      return app.appName
    },
    get instanceId() {
      return app.instanceId
    },
    get status() {
      return app.status
    },
    get hostName() {
      return app.hostName
    },
    get protocolVersion() {
      return app.protocolVersion
    },
    get context() {
      return app.context
    },
    get orderView() {
      return app.orderView
    },
    get notify() {
      return app.notify
    },
    reportFeature: (report) => app.reportFeature(report),
    updateContext: (patch) => app.updateContext(patch),
  }

  return {
    api,
    start() {
      if (disposed) return
      app.start()
    },
    dispose() {
      if (disposed) return
      disposed = true
      listeners.clear()
      app.dispose()
    },
    cancelDispose() {
      if (disposeTimer !== undefined) {
        clearTimeout(disposeTimer)
        disposeTimer = undefined
      }
    },
    scheduleDispose() {
      // StrictMode 会 mount → unmount → mount，effect 清理随即重跑。
      // 立刻 dispose 会把会话打死，第二次 mount 拿到一个已关闭的 app。
      // 推到下一个宏任务，重挂载时 cancelDispose 取消它。
      disposeTimer = setTimeout(() => {
        disposeTimer = undefined
        this.dispose()
      }, 0)
    },
    subscribe(listener) {
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },
    getState() {
      return cachedState
    },
    getServerState() {
      return serverState
    },
    getOrderView() {
      const view = app.orderView
      if (cachedView !== view) cachedView = view
      return cachedView
    },
  }
}

const FeatureStoreContext = createContext<FeatureStore | null>(null)

/**
 * 包在业务组件外面的那一层：管会话生命周期，把状态喂给下面的 hooks。
 */
function FeatureRoot({ options, props, children }: { options: FeatureComponentOptions; props: FeatureHostProps; children?: ReactNode }) {
  const [store] = useState(() => createFeatureStore(options, props))

  useEffect(() => {
    store.cancelDispose()
    store.start()
    return () => {
      store.scheduleDispose()
    }
  }, [store])

  return createElement(FeatureStoreContext.Provider, { value: store }, children)
}

function useStore(hookName: string): FeatureStore {
  const store = useContext(FeatureStoreContext)
  if (!store) {
    throw new Error(
      `[${hookName}] 必须在 createFeatureComponent 创建的组件内部使用：` +
        '上下文由 SDK 注入，直接挂载业务组件是拿不到的',
    )
  }
  return store
}

/**
 * 组件形态子应用的统一入口。
 *
 * @example
 * ```tsx
 * // 子应用 src/feature.tsx —— 功能模块形态（工单里的关联能力）
 * export const Feature = createFeatureComponent({
 *   appName: 'alert-order',
 *   Component: CellStatusView,
 * })
 *
 * // MF 配置：exposes: { './Feature': './src/feature.tsx' }
 * ```
 *
 * 业务组件里：
 * ```tsx
 * function CellStatusView() {
 *   const view = useOrderView()
 *   const api = useFeatureApi()
 *   if (!view?.ready) return <Empty text="等待工单数据" />
 *   return (
 *     <button onClick={() => api.reportFeature({ summary: '查询完成', data: result })}>
 *       {view.status}
 *     </button>
 *   )
 * }
 * ```
 */
export function createFeatureComponent(options: FeatureComponentOptions): ComponentType<FeatureHostProps> {
  const displayName = options.displayName ?? `Feature(${options.appName})`

  function FeatureComponent(props: FeatureHostProps): ReactNode {
    if (!isValidBridge(props?.bridge)) {
      // 不抛异常：宿主渲染出错会让整块界面白屏，这里给一条能照着改的提示
      options.onError?.(
        new ProtocolError(
          ProtocolErrorCode.InvalidPayload,
          `[${displayName}] 缺少 bridge：宿主必须传入 createFeatureBridge() 的 featureSide`,
        ),
      )
      return createElement(
        'div',
        { style: { padding: 16, fontSize: 13, color: '#71717a' }, role: 'alert' },
        `组件 ${options.appName} 缺少 bridge：请用 createHostApp + createFeatureBridge 承载（见接入指南）`,
      )
    }

    // 实例身份缺失时只有 appName 可过滤：同应用多工单会串上下文，开发期必须喊出来
    if (!props.instanceId && typeof console !== 'undefined') {
      console.warn(
        `[${displayName}] 没传 instanceId：同一子应用同时打开两个工单时会话会串上下文，` +
          '宿主请传 `<appName>_<业务主键>_<模块 id>`',
      )
    }

    return createElement(
      FeatureRoot,
      { options, props },
      createElement(options.Component, null),
    )
  }

  FeatureComponent.displayName = displayName
  return FeatureComponent
}

/** 宿主会话来与业务数据 */
export function useFeatureApi(): FeatureApi {
  return useStore('useFeatureApi').api
}

/** 会话状态（connecting / ready / standalone / closed） */
export function useFeatureState(): EntryAppState {
  const store = useStore('useFeatureState')
  return useSyncExternalStore(store.subscribe, store.getState, store.getServerState)
}

/**
 * 工单视图（**功能模块的唯一工单数据入口**）。
 *
 * 数据不是模块自己拉来的：详情载体（wujie 子应用）把快照报给宿主，
 * 宿主投影成 `OrderView`（裁掉页头动作、补 `ready`）后广播给同页所有模块。
 * 所以同页 N 个模块看到的是同一份工单数据，不会各拿各的。
 */
export function useOrderView(): OrderView | undefined {
  const store = useStore('useOrderView')
  return useSyncExternalStore(store.subscribe, store.getOrderView, getUndefinedSnapshot)
}

/** 工单上下文（orderId / orderType / ui / features），握手时随 welcome 下发 */
export function useFeatureContext(): WorkOrderContext | undefined {
  const state = useFeatureState()
  return state.context
}

/** 便捷：只取 toast / close / navigate */
export function useNotify(): EntryAppNotifier {
  return useStore('useNotify').api.notify
}

/** 子应用单独渲染（脱离宿主调试）时用的占位状态，避免 hooks 直接抛错 */
export { CONNECTING_STATE }
