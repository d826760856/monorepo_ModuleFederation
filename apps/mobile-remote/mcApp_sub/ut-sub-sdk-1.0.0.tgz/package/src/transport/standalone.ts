import { createNullTransport, type EventBusLike, type Transport } from '@ut/protocol'

/**
 * 独立运行传输：什么都不做。
 *
 * 子应用没有宿主时（`pnpm dev` 直接打开子应用、单测、Storybook）
 * 依然能正常渲染，只是拿不到按钮区和上下文。
 */
export function createStandaloneTransport(): Transport {
  return createNullTransport('standalone')
}

export type { EventBusLike }
