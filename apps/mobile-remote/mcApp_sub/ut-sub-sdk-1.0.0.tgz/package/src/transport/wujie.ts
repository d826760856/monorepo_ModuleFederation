import { CHANNEL, type EventBusLike, type Envelope, type Transport } from '@ut/protocol'

/**
 * 子应用侧 wujie 传输实现 —— 全工程唯一访问 `window.$wujie.bus` 的地方。
 *
 * 单通道 + Envelope.topic 分发，具体 topic 语义由 @ut/protocol 定义。
 */
export function createWujieSubTransport(bus: EventBusLike): Transport {
  const wrappers = new Set<(payload: unknown) => void>()

  return {
    kind: 'wujie',

    send(envelope) {
      bus.$emit(CHANNEL, envelope)
    },

    onMessage(handler) {
      const wrapper = (payload: unknown) => {
        handler(payload as Envelope)
      }
      wrappers.add(wrapper)
      bus.$on(CHANNEL, wrapper)
      return () => {
        wrappers.delete(wrapper)
        bus.$off(CHANNEL, wrapper)
      }
    },

    close() {
      for (const wrapper of wrappers) {
        bus.$off(CHANNEL, wrapper)
      }
      wrappers.clear()
    },
  }
}
