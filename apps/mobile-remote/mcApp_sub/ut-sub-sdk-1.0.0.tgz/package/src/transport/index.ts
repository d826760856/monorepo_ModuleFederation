import type { EventBusLike, Transport } from '@ut/protocol'
import { createWujieSubTransport } from './wujie'
import { createStandaloneTransport } from './standalone'

export { createWujieSubTransport, createStandaloneTransport }

/**
 * 无界注入到子应用 window 上的对象。
 *
 * 只声明 SDK 真正用到的那一小块（总线），不做完整建模 —— 完整类型由 wujie 包提供，
 * 而运行时注入的对象与包类型并不完全一致，过度建模反而容易绑死版本。
 *
 * 放在这里而不是单独的 `env.d.ts`：全局声明的文件必须被某个入口 import 到才会进入编译期，
 * 否则跨包引用（`@ut/sub-mf` → `@ut/sub-sdk`）时这条声明会缺席。
 */
declare global {
  interface Window {
    $wujie?: { bus?: EventBusLike }
  }
}

/**
 * 传输工厂：有宿主 bus 就走 wujie，没有就退化为独立运行。
 *
 * 注意这里是"探测后降级"，不是"探测失败抛错"：
 * 非 wujie 环境抛错会让整页白屏，而这本是正常的独立运行场景。
 */
export function createSubTransport(): Transport {
  const bus = typeof window === 'undefined' ? undefined : window.$wujie?.bus
  if (bus) return createWujieSubTransport(bus)
  return createStandaloneTransport()
}
