import {
  PROTOCOL_VERSION,
  ProtocolError,
  ProtocolErrorCode,
  Session,
  Topics,
  normalizeOrderSnapshot,
  toProtocolError,
  type ActionInvokePayload,
  type ActionResult,
  type EntryOrderSnapshot,
  type FeatureReport,
  type HelloPayload,
  type NotifyNavigatePayload,
  type NotifyToastPayload,
  type OrderSnapshot,
  type OrderGetPayload,
  type OrderView,
  type SubscriptionItem,
  type Surface,
  type Transport,
  type WelcomePayload,
  type WorkOrderContext,
} from '@ut/protocol'
import { createSubTransport } from './transport'

export { normalizeOrderSnapshot }
export type { EntryOrderSnapshot }

/**
 * 子应用接入契约的公共部分：身份 + 会话生命周期 + 状态。
 *
 * 两种承载（整页 wujie / 功能组件 MF）共用这一份，因为它们跑的是同一条会话：
 * 握手、心跳、上下文下发、生命周期、通知、降级，一行都不差。
 *
 * 差异只有两件事，各自放在下面对应的接口里：
 * - `DetailAppOptions`：工单数据的**提供方**（`order.provide`）
 * - `FeatureAppOptions`：工单数据的**消费方**（`order.view`）
 *
 * 身份只有 `appName` 一项，别的都不从这里进：
 * - `instanceId` 由宿主注入（整页：`$wujie.props.instanceId`；组件：props）。
 *   放进 options 就会有两个真相来源：宿主注入的是对的，接入方手填一个错的，
 *   SDK 还得挑一个信 —— 这类偏差最后都表现为"串上下文"，而且日志里看不出破绽。
 * - 展示名归宿主配置（`DetailConfig.name` → `TodoSource.name`、`FeatureConfig.name`），
 *   子应用报一份是多余的，它也不可能参与任何过滤。
 */
export interface SubAppBaseOptions {
  /** 远程应用名（机器名）。等于 MF remote 名 / wujie 子应用配置名，参与握手校验 */
  appName: string
  /** 宿主推进来新的上下文（切单、保活恢复、主题变更） */
  onContextChange?: (context: WorkOrderContext) => void
  /** 宿主要求刷新 */
  onRefresh?: (context: WorkOrderContext) => void | Promise<void>
  /** 保活挂起 / 恢复 */
  onPause?: () => void
  onResume?: () => void
  /** 容器销毁，做清理（取消计时器、退订） */
  onDestroy?: () => void
  /** 状态变化（含降级为 standalone）后回调 */
  onStateChange?: (state: EntryAppState) => void
  /** 链路级异常 */
  onError?: (error: ProtocolError) => void
  /** 心跳上报间隔（ms），0 关闭 */
  heartbeatInterval?: number
  /** 控制台通信日志；默认开启，排查主子握手时可传 false 关闭 */
  debug?: boolean
  /** 覆盖传输实现（单测 / 非 wujie、非 MF 场景） */
  transport?: Transport
}

/**
 * 整页嵌入（wujie）子应用的接入契约：声明 `order.provide`，是工单数据的提供方。
 *
 * 宿主打开这条待办时**只认这里的数据** —— 页头标题、状态文案、底部按钮
 * 全部来自 `getOrderSnapshot` 的返回，或 `pushOrderData` 之后的推送。
 */
export interface DetailAppOptions extends SubAppBaseOptions {
  /**
   * 宿主拉取工单快照（`order.get`）。
   *
   * 声明了 `order.provide` 就必须给：宿主首屏会等这一次返回。
   * 可以返回 Promise —— 首屏数据没加载完就保持 pending，
   * 宿主会显示骨架屏，而不是先渲染一版"无数据"。
   *
   * 参数是当前工单上下文（含 `orderId`），不能靠接入方猜。
   */
  getOrderSnapshot: (
    context: WorkOrderContext,
  ) => EntryOrderSnapshot | OrderSnapshot | Promise<EntryOrderSnapshot | OrderSnapshot>
  /** 宿主下发按钮点击（快照里出现过 actions 就必须实现） */
  onAction?: (
    action: ActionInvokePayload,
    context: WorkOrderContext,
  ) => ActionResult | void | Promise<ActionResult | void>
}

/**
 * 功能模块（MF 组件）的接入契约：声明 `order.view`，是工单数据的消费方。
 *
 * 这里**没有** `getOrderSnapshot` / `onAction`，不是省略：
 * 功能模块不拥有工单数据，宿主的 `order.get` 永远不会发到这里；
 * 快照与按钮归详情载体，模块只收宿主投影后的 `order.view`。
 */
export interface FeatureAppOptions extends SubAppBaseOptions {
  /**
   * 功能模块 id（`FeatureConfig.id`）。
   *
   * 同一子应用可能有多个功能模块（小区状态、基站状态……），上报数据时宿主靠它区分是谁报的。
   * 由宿主经 props 注入，接入方不需要手填；手填只用于脱离宿主单测。
   */
  moduleId?: string
  /**
   * 收到宿主广播的工单视图（`order.view`）。
   *
   * 组件形态的主数据入口：详情载体把快照报给宿主，宿主投影后分发给所有功能模块，
   * 所以同页 N 个模块看到的是同一份工单数据，不会各拿各的。
   * 不想用回调也可以：`useOrderView()` 读同一个值。
   */
  onOrderViewChange?: (view: OrderView) => void
}

export type EntryAppStatus =
  /** 已发出 hello，等宿主 welcome */
  | 'connecting'
  /** 握手成功 */
  | 'ready'
  /** 无宿主，独立运行（正常渲染但无上下文） */
  | 'standalone'
  /** 已关闭 */
  | 'closed'

export interface EntryAppState {
  status: EntryAppStatus
  appName: string
  instanceId: string | undefined
  hostName: string | undefined
  protocolVersion: number
  context: WorkOrderContext | undefined
  /** 宿主广播的工单视图；只有功能模块形态会有值 */
  orderView: OrderView | undefined
  /** 状态变化原因，埋点与排障用 */
  reason: string | undefined
  error: ProtocolError | undefined
}

/** 子应用能主动调宿主的几个动作，统一挂在 `notify` 下 */
export interface EntryAppNotifier {
  toast(payload: NotifyToastPayload | string): void
  close(reason?: string): void
  navigate(payload: NotifyNavigatePayload): void
}

/**
 * 功能模块上报的内容。
 *
 * `moduleId` / `orderId` / `at` 由 SDK 补齐（归属与去旧必须靠它们），
 * 模块只填业务部分 —— 让接入方手填 orderId，等于把"串单"的入口交出去。
 */
export type FeatureReportInput = Omit<FeatureReport, 'moduleId' | 'orderId' | 'at'> & {
  /** 覆盖模块 id（默认 `options.moduleId`，再退回 `appName`） */
  moduleId?: string
}

/** 两种承载共用的句柄：状态、订阅、上下文、通知、销毁 */
export interface SubAppHandle {
  readonly status: EntryAppStatus
  readonly state: EntryAppState
  readonly appName: string
  readonly instanceId: string | undefined
  readonly hostName: string | undefined
  readonly protocolVersion: number
  readonly context: WorkOrderContext | undefined
  readonly session: Session
  readonly notify: EntryAppNotifier
  /** 订阅状态变化（握手完成、上下文更新、降级），返回取消函数 */
  subscribe(listener: (state: EntryAppState) => void): () => void
  /**
   * 开始握手（发 hello）。
   *
   * 整页形态创建时已自动调过一次，业务侧通常用不到；
   * 组件形态下必须在 effect 里显式调用 —— render 期发消息是副作用，
   * React 严格模式会跑两遍 render，等于向宿主发两次 hello。
   * 幂等：重复调用只有第一次生效。
   */
  start(): void
  /** 合并上下文并把变更上报宿主（`context.update`） */
  updateContext(patch: Partial<WorkOrderContext>): void
  dispose(): void
}

/** 整页嵌入的句柄：工单数据归它，所以能推快照、能登记订阅 */
export interface DetailApp extends SubAppHandle {
  /**
   * 推送工单快照（`order.data`）。
   *
   * 未握手时**缓冲最后一份**，握手成功后补发。
   * 不缓冲的话，首屏渲染完了宿主还拿不到按钮。
   */
  pushOrderData(snapshot: EntryOrderSnapshot | OrderSnapshot): void
  /**
   * 向上登记一条订阅（`order.stream`）。
   *
   * 未握手时**缓冲**，握手成功后一次性补发。
   * 不缓冲的话，首屏数据已加载但主导航看不到这条待办。
   */
  pushSubscription(item: SubscriptionItem): void
  /** 取消一条订阅（条目失效、用户手动清除） */
  cancelSubscription(subId: string): void
}

/** 功能模块的句柄：工单数据从宿主来，所以能读视图、能上报自己的数据 */
export interface FeatureApp extends SubAppHandle {
  /** 宿主广播的工单视图（组件形态的数据源） */
  readonly orderView: OrderView | undefined
  /**
   * 上报本模块那部分数据（`feature.data`）。
   *
   * 宿主只做三件事：校验归属、去旧、按 moduleId 存 —— 不解释 `data` 的语义。
   * 未握手时缓冲最后一份（同一模块只留最新），握手后补发。
   */
  reportFeature(report: FeatureReportInput): void
}

/**
 * 承载方式注入的身份。
 *
 * 这是两种承载唯一的接缝：整页由 `createEntryApp` 从 `$wujie.props` 读，
 * 功能组件由 `createFeatureComponent` 从 React props 读。
 */
export interface SubAppIdentity {
  /** 实例身份；宿主没给就只能是 undefined（多实例会串上下文，开发期告警） */
  instanceId?: string
  /** 传输实现；不传则用默认（wujie 总线 / 独立运行） */
  transport?: Transport
  /**
   * 延迟握手。
   *
   * 组件形态必须为 true：`createFeatureComponent` 在 render 期建会话，
   * 发消息这件事得挪到 effect 里（`app.start()`）。
   */
  deferHandshake?: boolean
}

/**
 * 承载面专属的回调。
 *
 * 单独一个参数而不是直接从 options 里读：核心机器要同时服务两种契约，
 * 而"详情面才有的钩子"与"功能面才有的钩子"在类型上必须分开，
 * 否则只能靠 as 断言把它抹平 —— 那正是这一轮要消掉的旧定位。
 */
interface SurfaceBindings {
  getOrderSnapshot?: DetailAppOptions['getOrderSnapshot']
  onAction?: DetailAppOptions['onAction']
  onOrderViewChange?: FeatureAppOptions['onOrderViewChange']
  /** 上报归属用的模块 id（功能面） */
  moduleId?: string
}

/** 子应用等待宿主 welcome 的耐心：8 次 × 2ms→256ms 退避 ≈ 0.5s */
const HANDSHAKE_RETRIES = 8

/** appName 只允许字母数字和连字符：它会进 wujie 实例名、日志和路由 */
export const APP_NAME_PATTERN = /^[a-zA-Z][a-zA-Z0-9-]*$/

export function isDevMode(): boolean {
  const proc = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process
  if (proc?.env?.NODE_ENV) return proc.env.NODE_ENV !== 'production'
  const flag = (globalThis as { __UT_DEV__?: boolean }).__UT_DEV__
  return flag !== false
}

/** 默认心跳间隔（ms），可被 options / welcome 覆盖 */
const DEFAULT_HEARTBEAT_INTERVAL = 15_000

/**
 * 建子应用会话。两种承载共用这一台机器，调用方用 `createDetailApp` /
 * `createFeatureApp` 各取所需，不必自己传 surface。
 *
 * 不对外导出是刻意的：`surface` 与 `bindings` 必须配套
 * （给功能面塞 `getOrderSnapshot`、给详情面塞 `reportFeature` 都是错的），
 * 让两个装配器把它们绑死，调用方就没有拼错的机会。
 */
function createSubAppCore(
  options: SubAppBaseOptions,
  surface: Surface,
  bindings: SurfaceBindings,
  identity: SubAppIdentity = {},
): DetailApp & FeatureApp {
  if (!APP_NAME_PATTERN.test(options.appName)) {
    const message = `appName 只能由字母、数字和连字符组成，且以字母开头，收到 "${options.appName}"`
    if (isDevMode()) throw new ProtocolError(ProtocolErrorCode.InvalidPayload, message)
    console.warn(`[@ut/sub-sdk] ${message}`)
  }

  const instanceId = identity.instanceId
  const transport = identity.transport ?? options.transport ?? createSubTransport()
  const heartbeatInterval = options.heartbeatInterval ?? DEFAULT_HEARTBEAT_INTERVAL

  const state: EntryAppState = {
    status: 'connecting',
    appName: options.appName,
    instanceId,
    hostName: undefined,
    protocolVersion: PROTOCOL_VERSION,
    context: undefined,
    orderView: undefined,
    reason: undefined,
    error: undefined,
  }

  const stateListeners = new Set<(state: EntryAppState) => void>()
  let bufferedSubscriptions: SubscriptionItem[] = []
  /** 握手期间的最新快照：快照是全量状态，只留最后一份 */
  let bufferedSnapshot: OrderSnapshot | undefined
  /** 握手期间各模块的上报：按 moduleId 只留最新一份 */
  const bufferedReports = new Map<string, FeatureReport>()

  const notify = (): void => {
    options.onStateChange?.({ ...state })
    for (const listener of stateListeners) listener({ ...state })
  }

  const setStatus = (status: EntryAppStatus, reason: string): void => {
    state.status = status
    state.reason = reason
    notify()
  }

  const session = new Session({
    self: { app: options.appName, role: 'sub', instanceId, surface },
    transport,
    // 子应用只认宿主；instanceId 在 welcome 之后才补上
    acceptFrom: { role: 'host' },
    defaultTo: { role: 'host' },
    heartbeatInterval,
    debug: options.debug,
    onError: (error) => {
      state.error = error
      options.onError?.(error)
    },
  })

  function applyWelcome(payload: WelcomePayload): void {
    state.hostName = payload.hostName
    state.protocolVersion = payload.protocolVersion ?? PROTOCOL_VERSION
    state.context = { ...(state.context ?? {}), ...(payload.context ?? {}) }
    // welcome 之后宿主实例身份确定了，后续消息精确投递，不再广播
    session.setDefaultTo({ app: payload.hostName, role: 'host', instanceId: payload.instanceId })
  }

  session.on(Topics.SessionWelcome, (payload) => {
    applyWelcome(payload as WelcomePayload)
    session.markReady()
    setStatus('ready', 'welcome')

    // 补发握手期间积压的订阅（宿主没收到过，所以要重放给宿主，而不是只喂本地回调）
    const pending = bufferedSubscriptions
    bufferedSubscriptions = []
    for (const item of pending) session.emit(Topics.OrderStream, item)

    // 补发握手期间的最新快照
    if (bufferedSnapshot) {
      session.emit(Topics.OrderData, bufferedSnapshot)
      bufferedSnapshot = undefined
    }

    // 补发握手期间各模块的上报（组件可能在 welcome 之前就算完了首屏数据）
    if (bufferedReports.size > 0) {
      const pendingReports = Array.from(bufferedReports.values())
      bufferedReports.clear()
      for (const report of pendingReports) session.emit(Topics.FeatureData, report)
    }

    options.onContextChange?.(state.context ?? {})
  })

  // `order.get` 只有详情面应答。功能面收到就是宿主配置错了（把 detail 应用挂在
  // feature 槽位），显式拒绝比让宿主等 8 秒超时好查得多。
  session.on(Topics.OrderGet, async (payload) => {
    if (surface === 'feature') {
      throw new ProtocolError(
        ProtocolErrorCode.NotSupported,
        `${options.appName} 是功能模块，不提供工单快照：order.get 只发给详情载体`,
      )
    }
    if (!bindings.getOrderSnapshot) {
      throw new ProtocolError(
        ProtocolErrorCode.NotSupported,
        '声明了 order.provide 但没有实现 getOrderSnapshot',
      )
    }
    // 首屏请求自己带上下文，不能只依赖 welcome：宿主 resolve ready 时，
    // welcome 响应可能尚未送达。这里先合并，保证 getOrderSnapshot 首次调用
    // 就能拿到 orderId 等工单级信息。
    const requestedContext = (payload as Partial<OrderGetPayload> | undefined)?.context
    if (requestedContext && typeof requestedContext === 'object') {
      state.context = { ...(state.context ?? {}), ...requestedContext }
      notify()
      options.onContextChange?.(state.context)
    }
    const snapshot = await bindings.getOrderSnapshot(state.context ?? {})
    if (!snapshot) {
      throw new ProtocolError(ProtocolErrorCode.InvalidPayload, 'getOrderSnapshot 返回了空快照')
    }
    return normalizeOrderSnapshot(snapshot)
  })

  session.on(Topics.ActionInvoke, async (payload) => {
    if (surface === 'feature') {
      throw new ProtocolError(
        ProtocolErrorCode.NotSupported,
        `${options.appName} 是功能模块，不接受动作下发：action.invoke 只发给详情载体`,
      )
    }
    const action = (payload ?? { key: '' }) as ActionInvokePayload
    try {
      const result = await bindings.onAction?.(action, state.context ?? {})
      return result ?? { ok: true }
    } catch (error) {
      const normalized = toProtocolError(error)
      options.onError?.(normalized)
      return { ok: false, message: normalized.message } satisfies ActionResult
    }
  })

  session.on(Topics.OrderContext, (payload) => {
    if (!payload || typeof payload !== 'object') return
    state.context = { ...(state.context ?? {}), ...(payload as Partial<WorkOrderContext>) }
    notify()
    options.onContextChange?.(state.context)
  })

  // 宿主广播的工单视图：功能模块的唯一工单数据入口（一对多，evt，不回复）
  session.on(Topics.OrderView, (payload) => {
    if (!payload || typeof payload !== 'object') return
    state.orderView = payload as OrderView
    notify()
    bindings.onOrderViewChange?.(state.orderView)
  })

  session.on(Topics.LifecycleRefresh, async () => {
    await options.onRefresh?.(state.context ?? {})
  })

  session.on(Topics.LifecyclePause, () => {
    options.onPause?.()
  })

  session.on(Topics.LifecycleResume, () => {
    options.onResume?.()
  })

  // 销毁可能来自两条通道：语义层 lifecycle.destroy（宿主正常关闭）与链路层
  // session.close（宿主异常/超时）。两者都要收敛到 onDestroy，但只能调用一次。
  let destroyed = false
  const handleDestroy = (reason: string): void => {
    if (destroyed) return
    destroyed = true
    options.onDestroy?.()
    setStatus('closed', reason)
  }

  session.on(Topics.LifecycleDestroy, () => {
    handleDestroy('host-destroy')
  })

  session.on(Topics.SessionClose, () => {
    handleDestroy('session-close')
  })

  const hello: HelloPayload = {
    appName: options.appName,
    instanceId,
    mode:
      transport.kind === 'wujie'
        ? 'wujie'
        : transport.kind === 'mf'
          ? 'mf'
          : transport.kind === 'memory'
            ? 'memory'
            : 'standalone',
    surface,
    protocolVersion: PROTOCOL_VERSION,
  }

  /** 握手只发起一次：组件形态下 effect、StrictMode、重试都可能重复调用 start */
  let handshakeStarted = false
  function start(): void {
    if (handshakeStarted || destroyed) return
    handshakeStarted = true

    // 会话注册完毕，开始握手：发 hello（req），宿主回 welcome（res）
    void session
      .request<WelcomePayload>(Topics.SessionHello, hello, {
        timeout: 2000,
        retries: HANDSHAKE_RETRIES,
      })
      .then((welcome) => {
        if (!welcome) throw new ProtocolError(ProtocolErrorCode.Timeout, '宿主未返回 welcome')
        // 正常路径下 welcome 已由 session.on(SessionWelcome) 处理，这里兜底幂等
        if (state.status !== 'ready') {
          applyWelcome(welcome)
          session.markReady()
          setStatus('ready', 'welcome-res')
        }
      })
      .catch((error: unknown) => {
        const normalized = toProtocolError(error)
        // 关键：握手失败不抛、不白屏，降级为独立运行
        state.error = normalized
        state.hostName = undefined
        setStatus('standalone', 'handshake-timeout')
        options.onError?.(normalized)
      })
  }

  if (!identity.deferHandshake) start()

  const notifyApi: EntryAppNotifier = {
    toast(payload) {
      const body: NotifyToastPayload =
        typeof payload === 'string' ? { message: payload } : payload
      session.emit(Topics.NotifyToast, body)
    },
    close(reason) {
      session.emit(Topics.NotifyClose, reason === undefined ? undefined : { reason })
    },
    navigate(payload) {
      session.emit(Topics.NotifyNavigate, payload)
    },
  }

  /**
   * 出站方向也按承载面收口。
   *
   * 编译期已经把这几个方法从 `FeatureApp` 上摘掉了，这里兜的是 JS 调用方
   * 与"拿到的是 DetailApp、跑起来却在功能槽位"的错配 —— 两种情况的唯一表现
   * 都是宿主侧悄悄不生效，日志里没有痕迹。
   */
  function assertDetailSurface(action: string): void {
    if (surface === 'feature') {
      throw new ProtocolError(
        ProtocolErrorCode.NotSupported,
        `功能模块不${action}：工单快照与订阅归详情载体（${options.appName} 声明的是 order.view）`,
      )
    }
  }

  return {
    get status() {
      return state.status
    },
    get state() {
      return { ...state }
    },
    get appName() {
      return state.appName
    },
    get instanceId() {
      return state.instanceId
    },
    get hostName() {
      return state.hostName
    },
    get protocolVersion() {
      return state.protocolVersion
    },
    get context() {
      return state.context
    },
    get orderView() {
      return state.orderView
    },
    get session() {
      return session
    },
    get notify() {
      return notifyApi
    },
    subscribe(listener) {
      stateListeners.add(listener)
      return () => {
        stateListeners.delete(listener)
      }
    },
    start,
    updateContext(patch) {
      state.context = { ...(state.context ?? {}), ...patch }
      if (state.status === 'ready') session.emit(Topics.ContextUpdate, patch)
      notify()
    },
    pushOrderData(snapshot) {
      assertDetailSurface('推送工单快照')
      const protocolSnapshot = normalizeOrderSnapshot(snapshot)
      if (state.status === 'ready') {
        session.emit(Topics.OrderData, protocolSnapshot)
      } else {
        bufferedSnapshot = protocolSnapshot
      }
    },
    pushSubscription(item) {
      assertDetailSurface('登记订阅')
      // 老版本子应用不带 appName / updatedAt，这儿补齐，宿主不用再猜
      const normalized: SubscriptionItem = {
        ...item,
        appName: item.appName || options.appName,
        orderId: item.orderId || state.context?.orderId || '',
        updatedAt: item.updatedAt || Date.now(),
      }
      if (state.status === 'ready') {
        session.emit(Topics.OrderStream, normalized)
      } else {
        bufferedSubscriptions.push(normalized)
      }
    },
    cancelSubscription(subId) {
      assertDetailSurface('取消订阅')
      const index = bufferedSubscriptions.findIndex((item) => item.subId === subId)
      if (index >= 0) bufferedSubscriptions.splice(index, 1)
      if (state.status === 'ready') session.emit(Topics.SubscriptionCancel, { subId })
    },
    reportFeature(input) {
      const report: FeatureReport = {
        ...input,
        // 归属与新鲜度由 SDK 补，接入方不用关心
        moduleId: input.moduleId || bindings.moduleId || options.appName,
        orderId: state.context?.orderId ?? '',
        at: Date.now(),
      } as FeatureReport
      if (state.status === 'ready') {
        session.emit(Topics.FeatureData, report)
      } else {
        bufferedReports.set(report.moduleId, report)
      }
    },
    dispose() {
      bufferedSubscriptions = []
      bufferedSnapshot = undefined
      bufferedReports.clear()
      stateListeners.clear()
      session.close('dispose')
      setStatus('closed', 'dispose')
    },
  }
}

/**
 * 建**整页嵌入**子应用的会话（`order.provide`，工单数据的提供方）。
 *
 * 业务侧一般不直接调用它，由 `createEntryApp` 从 wujie 注入的 props 取身份后调用。
 */
export function createDetailApp(options: DetailAppOptions, identity: SubAppIdentity = {}): DetailApp {
  return createSubAppCore(
    options,
    'detail',
    { getOrderSnapshot: options.getOrderSnapshot, onAction: options.onAction },
    identity,
  )
}

/**
 * 建**功能模块**（MF 组件）的会话（`order.view`，工单数据的消费方）。
 *
 * 业务侧一般不直接调用它，由 `createFeatureComponent` 从 React props 取身份后调用。
 */
export function createFeatureApp(
  options: FeatureAppOptions,
  identity: SubAppIdentity = {},
): FeatureApp {
  return createSubAppCore(
    options,
    'feature',
    { moduleId: options.moduleId, onOrderViewChange: options.onOrderViewChange },
    identity,
  )
}
