import { createDetailApp, isDevMode } from './core'
import type { DetailApp, DetailAppOptions } from './core'

// 契约与句柄类型都在 core 里，这里原样透出：`@ut/sub-sdk` 的公开面不因为
// 内部拆分而变（接入方 import 的还是同一个包名）。
export * from './core'
export { MOBILE_DEFAULT_ACTIONS_BY_STATUS } from '@ut/protocol'
export type { ActionKey, MobileDefaultActionKey } from '@ut/protocol'

/** 从 wujie 注入的 props 里取宿主给的实例标识 */
function readInjectedProps(): { instanceId?: string; appName?: string } {
  const wujie = (globalThis as { $wujie?: { props?: Record<string, unknown> } }).$wujie
  const props = wujie?.props
  if (!props) return {}
  return {
    instanceId: typeof props.instanceId === 'string' ? props.instanceId : undefined,
    appName: typeof props.appName === 'string' ? props.appName : undefined,
  }
}

/**
 * 在线的整页会话，键为 `appName::instanceId`。
 *
 * 一个子应用实例只该有一条会话：宿主下发只按 `{app, role, instanceId}` 过滤，
 * 两条会话的 `self` 一模一样，于是同一条消息两边都收 —— 一次点击被处理两遍，
 * 而且旧的那条不会自己退场。落点只能在子应用侧，宿主分不出来。
 */
const liveEntryApps = new Map<string, DetailApp>()

/**
 * 整页嵌入子应用统一入口：同一实例同时只有一条会话。
 *
 * 创建是幂等安全的：同一 `appName` + `instanceId` 已有会话时，先接管（关闭旧会话）
 * 再建新的，所以放在组件里、effect 里、模块顶层都行，不会并存两条。
 * 后创建的那次回调生效 —— 组件重渲染、严格模式双挂载、HMR 都是这个走向；
 * 这些属于正常路径，不告警。
 *
 * `dispose()` 也据此定义：只在「自己仍是当前会话」时真正关闭，
 * 已被接管或重复调用都是空操作，因此卸载回调里可以直接调。
 *
 * 身份从 wujie 注入的 props 里读（宿主渲染 `<WujieReact>` 时 `props={{ instanceId }}`）：
 * 多一份来源就多一次串上下文的机会。
 *
 * 功能组件（MF）形态用 `@ut/sub-mf` 的 `createFeatureComponent`：
 * 那是另一份契约（`FeatureAppOptions`），不提供 `getOrderSnapshot` / `onAction`，
 * 只消费宿主广播的 `order.view` —— 功能模块不拥有工单数据。
 *
 * @example
 * ```tsx
 * // 详情页组件里直接建，不需要包 useState / useRef 做单例
 * const app = createEntryApp({
 *   appName: 'guanghua-rru',
 *   getOrderSnapshot: (context) => buildSnapshot(context.orderId),
 *   onAction: ({ key }) => handleAction(key),
 * })
 *
 * const [ctx, setCtx] = useState(app.context)
 * useEffect(() => {
 *   const off = app.subscribe((state) => setCtx(state.context))
 *   // 已被接管时这里是空操作，重复调用也安全
 *   return () => { off(); app.dispose() }
 * }, [app])
 * ```
 *
 * 注意别在 render 期调用：每次渲染都会建一条再关掉一条，虽然不再并存，
 * 但握手会反复做，白白抖一下通道。放在组件顶部只执行一次的位置（模块顶层、
 * `useState` 初始值函数、`useMemo`）仍然更省。
 */
export function createEntryApp(options: DetailAppOptions): DetailApp {
  const injected = readInjectedProps()
  const key = `${options.appName}::${injected.instanceId ?? ''}`
  const existing = liveEntryApps.get(key)

  if (existing) {
    // 严格模式下初始值函数会被调用两次、HMR 会重跑模块，这些都是正常路径，
    // 所以这里不告警，只保证新旧不并存。
    existing.dispose()
  }

  if (isDevMode() && injected.instanceId === undefined) {
    console.warn(
      '[@ut/sub-sdk] 没取到 instanceId（$wujie.props.instanceId），只能按 appName 过滤：' +
        '同一子应用同时打开两个工单时，会话会串到另一条工单的上下文上',
    )
  }

  if (isDevMode() && injected.appName && injected.appName !== options.appName) {
    console.warn(
      `[@ut/sub-sdk] appName 不一致：options 里是 "${options.appName}"，宿主注入的是 "${injected.appName}"，` +
        '握手会被宿主过滤掉',
    )
  }

  const app = createDetailApp(options, { instanceId: injected.instanceId })
  liveEntryApps.set(key, app)

  const close = app.dispose
  app.dispose = () => {
    // 已被后来者接管：这条不是当前会话，关它会误伤正在用的那条
    if (liveEntryApps.get(key) !== app) return
    liveEntryApps.delete(key)
    close.call(app)
  }

  return app
}
