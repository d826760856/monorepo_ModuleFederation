import type { EventBusLike } from '@ut/protocol'

/**
 * 无界注入到子应用 window 上的对象。
 *
 * 这里只声明 SDK 真正用到的那一小块，不做完整建模 —— 完整类型由 wujie 包提供，
 * 而子应用运行时注入的对象与包类型并不完全一致，过度建模反而容易绑死版本。
 */
declare global {
  interface Window {
    $wujie?: { bus?: EventBusLike }
  }
}

export {}
