# `@ut/sub-sdk` 子应用调用示例

`@ut/sub-sdk` 是整页子应用的接入入口。每个子应用在启动时创建一个 `EntryApp` 实例；页面和业务代码复用该实例，不要在组件 render 或每次路由切换时重复创建。

## 1. 创建 SDK 实例

```ts
// src/entry-app.ts
import { createEntryApp, type EntryOrderSnapshot } from '@ut/sub-sdk'
import type { WorkOrderContext } from '@ut/protocol'
import { orderService } from './services/order-service'

let context: WorkOrderContext = {}

async function getSnapshot(): Promise<EntryOrderSnapshot> {
  const orderId = context.orderId
  if (!orderId) {
    throw new Error('宿主尚未下发工单上下文')
  }

  const order = await orderService.get(orderId)
  return {
    orderId: order.id,
    updatedAt: Date.now(),
    status: order.status,
    title: order.title,
    creator: order.assignee,
    actions: [
      { key: 'accept', label: '立即接单', primary: true },
    ],
  }
}

export const entryApp = createEntryApp({
  // 必须与宿主能力配置中的 appName 完全一致
  appName: 'guanghua-rru',
  capabilities: ['order.data', 'order.stream', 'lifecycle', 'notify'],

  // 宿主首屏通过 order.get 拉取快照
  getOrderSnapshot: getSnapshot,

  // 宿主把欢迎握手中的工单上下文交给子应用
  onContextChange(nextContext) {
    context = { ...context, ...nextContext }
  },

  // 处理宿主详情页上的按钮点击
  async onAction({ key }) {
    if (key !== 'accept') {
      return { ok: false, message: `不支持的操作：${key}` }
    }

    const orderId = context.orderId
    if (!orderId) {
      return { ok: false, message: '缺少工单上下文' }
    }

    await orderService.accept(orderId)
    entryApp.notify.toast({ message: '接单成功', level: 'success' })
    // 操作完成后推送最新快照，宿主用新快照更新标题、状态和按钮
    entryApp.pushOrderData(await getSnapshot())
    return { ok: true }
  },

  // 宿主触发刷新时重新读取业务数据并推送
  async onRefresh() {
    entryApp.pushOrderData(await getSnapshot())
  },

  onStateChange(state) {
    console.info('[sub-sdk]', state.status, state.reason)
  },
  onError(error) {
    console.error('[sub-sdk] 通信异常', error)
  },
})
```

上面的 `orderService` 代表子应用自己的业务 API；请替换为实际服务。`appName` 要与宿主配置的 `appName` 相同。使用 Wujie 时，`instanceId` 由宿主通过 `$wujie.props.instanceId` 注入，子应用不需要自行填写。

### 宿主默认按钮和 `onAction`

移动端宿主会根据工单状态自动补充以下按钮；这些按钮不需要写进子应用返回的 `actions`，但点击后同样会通过 `onAction` 回调给子应用：

| 工单状态 | key | 按钮文本 |
| --- | --- | --- |
| `pending` | `reassign` | 转派 |
| `pending` | `save` | 暂存 |
| `pending` | `return` | 返单 |
| `to-accept` | `accept-now` | 立即接单 |

因此，`onAction` 需要同时处理自定义按钮和这些默认按钮。例如：

```ts
async onAction({ key, args }) {
  switch (key) {
    case 'reassign':
      return handleReassign(args)
    case 'save':
      return handleSave(args)
    case 'return':
      return handleReturn(args)
    case 'accept-now':
      return handleAcceptNow(args)
    default:
      return handleCustomAction(key, args)
  }
}
```

SDK 导出的 `ActionKey` 类型和 `MOBILE_DEFAULT_ACTIONS_BY_STATUS` 常量也包含这组约定，接入代码可以直接导入以获得编辑器提示：

```ts
import {
  MOBILE_DEFAULT_ACTIONS_BY_STATUS,
  type ActionKey,
} from '@ut/sub-sdk'
```

默认按钮会排在子应用自定义 `actions` 之前；按钮超过移动端首屏展示数量时，后面的按钮会收进“更多操作”。

## 2. 在页面中读取上下文

React 页面订阅 SDK 状态，在宿主下发上下文后加载对应工单。订阅应在组件卸载时取消；不要在普通页面卸载时调用 `entryApp.dispose()`，因为 SDK 实例是应用级单例。

```tsx
// src/pages/OrderPage.tsx
import { useEffect, useState } from 'react'
import type { EntryAppState } from '@ut/sub-sdk'
import { entryApp } from '../entry-app'

export function OrderPage() {
  const [sdkState, setSdkState] = useState<EntryAppState>(entryApp.state)

  useEffect(() => entryApp.subscribe(setSdkState), [])

  const orderId = sdkState.context?.orderId

  if (sdkState.status === 'connecting') return <p>正在连接统一待办…</p>
  if (!orderId) return <p>当前以独立模式运行，尚无工单上下文</p>

  return <p>当前工单：{orderId}</p>
}
```

握手失败时 SDK 会进入 `standalone`，子应用仍可独立运行；此时宿主上下文不存在，页面应按自身产品行为处理。

## 3. 主动推送订阅和上下文

列表数据发生变化时，可以登记或更新订阅条目；不再关注时取消订阅。SDK 会在握手完成前缓冲订阅。

```ts
entryApp.pushSubscription({
  subId: 'order-WO20261026001',
  appName: entryApp.appName,
  entityType: 'order',
  businessKey: 'WO20261026001',
  orderId: 'WO20261026001',
  title: '传输线路故障工单',
  summary: '等待处理',
  status: 'live',
  updatedAt: Date.now(),
  version: 1,
})

// 工单不再需要显示为待办时
entryApp.cancelSubscription('order-WO20261026001')

// 子应用需要让宿主同步部分工单上下文时
entryApp.updateContext({ orderType: 'network-fault' })
```

`pushOrderData`、`pushSubscription` 可以在握手完成前调用，SDK 会缓冲快照/订阅并在握手成功后补发。应用真正销毁时（例如微前端根实例卸载）再调用 `entryApp.dispose()` 清理会话。

```ts
// src/entry-app.ts
import { createEntryApp, type EntryApp, type EntryOrderSnapshot } from '@ut/sub-sdk'
import type { WorkOrderContext } from '@ut/protocol'

let context: WorkOrderContext = {}
let entryApp: EntryApp

function getSnapshot(): EntryOrderSnapshot {
  return {
    orderId: context.orderId ?? 'ruaa',
    updatedAt: Date.now(),
    status: 'pending',
    title: '这是一个工单标题',
    creator: '王伟',
    actions: [{ key: 'accept', label: '立即接单', primary: true }],
  }
}

entryApp = createEntryApp({
  appName: 'guanghua-rru',
  capabilities: ['order.data', 'order.stream', 'lifecycle', 'notify'],

  getOrderSnapshot: getSnapshot,

  onContextChange(nextContext) {
    context = { ...context, ...nextContext }
    console.log('context', context)
  },

  async onAction({ key }) {
    if (key !== 'accept') {
      return { ok: false, message: `不支持的操作：${key}` }
    }

    entryApp.notify.toast({ message: '接单成功', level: 'success' })
    entryApp.pushOrderData(getSnapshot())
    return { ok: true }
  },

  onRefresh() {
    entryApp.pushOrderData(getSnapshot())
  },

  onStateChange(state) {
    console.info('[sub-sdk]', state.status, state.reason)
  },
  onError(error) {
    console.error('[sub-sdk] 通信异常', error)
  },
})

export { entryApp }
```
