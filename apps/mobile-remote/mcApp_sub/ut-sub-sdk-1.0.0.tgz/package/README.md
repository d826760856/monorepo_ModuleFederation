# @ut/sub-sdk

`@ut/sub-sdk` 用于把整页子应用接入统一待办的工单详情页。

子应用负责提供工单快照和处理按钮动作，宿主负责承载页面、渲染页头与底部按钮，并把工单上下文传给子应用。

```text
宿主 → 子应用：工单上下文、刷新、生命周期、按钮点击
子应用 → 宿主：工单快照、待办订阅、提示、跳转请求
```

本文只介绍整页详情接入。功能模块使用 `@ut/sub-mf` 的 `order.view` 契约，不要用 `createEntryApp` 接入功能槽位。

## 1. 安装

### 使用 npm 私有仓库

```bash
pnpm add @ut/protocol @ut/sub-sdk
```

`@ut/sub-sdk` 将 `@ut/protocol` 声明为 peer dependency，两个包需要使用兼容的主版本。

### 使用离线 tarball

在统一待办仓库根目录生成发布包：

```bash
pnpm pack:ut
```

在子应用中一起安装 protocol 和 sub-sdk：

```bash
pnpm add ./ut-protocol-1.0.0.tgz ./ut-sub-sdk-1.0.0.tgz
```

## 2. 接入前约定

- `appName` 必须和宿主能力配置中的 `appName` 逐字一致。建议使用全小写英文、数字和连字符，例如 `guanghua-rru`。
- 子应用应该是可以独立访问的普通 SPA。
- 嵌入统一待办时，工单号从 `context.orderId` 读取，不要解析宿主 URL。
- `createEntryApp()` 每个子应用实例只创建一次。React 页面可以放在 `useState` 初始值函数中；跨页面复用时可以放在模块顶层。
- Wujie 的 `instanceId` 由宿主通过 `$wujie.props.instanceId` 注入，子应用不需要自行填写。

## 3. 推荐接入方式：React 页面级会话

下面的 `api`、`handleAction` 和页面内容是业务代码，需要替换成子应用自己的实现。

```tsx
// src/pages/detail/DetailPage.tsx
import { useEffect, useState } from 'react'
import {
  createEntryApp,
  type DetailApp,
  type EntryAppState,
  type EntryOrderSnapshot,
} from '@ut/sub-sdk'

// 业务项目自己的接口封装
import { api } from '../../api'

export function DetailPage() {
  const [app] = useState(() => {
    let instance: DetailApp

    instance = createEntryApp({
      appName: 'guanghua-rru',

      // 宿主调用 order.get 时传入当前工单上下文。
      // 首屏工单号直接使用这个参数，不依赖 app.context 或 URL。
      getOrderSnapshot: async (context): Promise<EntryOrderSnapshot> => {
        if (!context.orderId) {
          throw new Error('缺少工单号')
        }

        const order = await api.getSnapshot(context.orderId)
        return {
          orderId: order.orderId,
          updatedAt: Date.now(),
          status: order.status,
          title: order.title,
          creator: order.creator,
          actions: [
            { key: 'mark-read', label: '标记已读' },
          ],
        }
      },

      // action 是宿主下发的按钮，context 是当前工单上下文。
      async onAction({ key, args }, context) {
        if (!context.orderId) {
          return { ok: false, message: '缺少工单号' }
        }

        switch (key) {
          // 移动端 todo / pendingAcceptance 来源菜单可能自动补充这些按钮，
          // 子应用需要实现宿主实际展示的默认按钮。
          case 'reassign':
          case 'save':
          case 'return':
          case 'accept-now':
          case 'mark-read':
            await api.handleAction({
              key,
              orderId: context.orderId,
              args,
            })
            instance.pushOrderData(await api.getSnapshot(context.orderId))
            return { ok: true }

          default:
            return { ok: false, message: `未知动作：${key}` }
        }
      },

      onContextChange(context) {
        // 切换工单或保活恢复时，按新的 orderId 刷新页面数据。
        console.info('[detail] context changed', context)
      },

      async onRefresh(context) {
        if (context.orderId) {
          instance.pushOrderData(await api.getSnapshot(context.orderId))
        }
      },

      onPause() {
        // 停止轮询、WebSocket 等后台任务。
      },

      onResume() {
        // 恢复后台任务，并按 instance.context?.orderId 重新加载。
      },

      onDestroy() {
        // 清理定时器、取消订阅、关闭业务连接。
      },

      onStateChange(state) {
        console.info('[sub-sdk]', state.status, state.reason)
      },

      onError(error) {
        console.error('[sub-sdk] 链路异常', error)
      },
    })

    return instance
  })

  const [state, setState] = useState<EntryAppState>(app.state)

  useEffect(() => {
    // 先订阅，再读取一次当前状态，避免错过已经到达的 welcome。
    const off = app.subscribe(setState)
    setState(app.state)

    return () => {
      off()
      app.dispose()
    }
  }, [app])

  const orderId = state.context?.orderId

  if (state.status === 'connecting') return <p>正在连接统一待办…</p>
  if (!orderId) return <p>当前没有工单上下文</p>

  return <p>当前工单：{orderId}</p>
}
```

### `context` 的时机

`createEntryApp()` 刚创建时，`app.context` 可能是 `undefined`。这是正常的：握手完成后宿主才会把上下文写入 SDK 状态。

首屏拉取快照时，宿主会把上下文放在 `order.get` 请求里，因此下面的参数就是当前工单上下文：

```ts
getOrderSnapshot: async (context) => {
  console.log(context.orderId)
  return api.getSnapshot(context.orderId!)
}
```

页面需要响应上下文变化时，使用 `onContextChange` 或 `subscribe`：

```ts
const off = app.subscribe((state) => {
  console.log(state.context?.orderId)
})
```

`getOrderSnapshot(context)` 和 `onAction(action, context)` 都会收到当前上下文，不需要通过模块级变量保存工单号。

### Vue 组合式 API

SDK 与框架无关。在 Vue 中，在 `script setup` 创建会话，在组件卸载时取消订阅并销毁页面级会话：

```vue
<script setup lang="ts">
import { onMounted, onUnmounted, ref } from 'vue'
import { createEntryApp } from '@ut/sub-sdk'
import { api } from '../../api'

const app = createEntryApp({
  appName: 'guanghua-rru',
  getOrderSnapshot: (context) => {
    if (!context.orderId) throw new Error('缺少工单号')
    return api.getSnapshot(context.orderId)
  },
  onAction: (action, context) => api.handleAction({
    key: action.key,
    orderId: context.orderId,
    args: action.args,
  }),
})

const state = ref(app.state)
let off: (() => void) | undefined

onMounted(() => {
  off = app.subscribe((nextState) => { state.value = nextState })
  state.value = app.state
})

onUnmounted(() => {
  off?.()
  app.dispose()
})
</script>
```

## 4. 跨页面复用一个会话

如果子应用内部有列表页和详情页之间的路由切换，可以把会话放在模块顶层。此时普通页面卸载时不要调用 `dispose()`，只在整个子应用根实例销毁时调用。

```ts
// src/entry-app.ts
import { createEntryApp } from '@ut/sub-sdk'
import { api } from './api'

export const entryApp = createEntryApp({
  appName: 'guanghua-rru',

  getOrderSnapshot: (context) => {
    if (!context.orderId) throw new Error('缺少工单号')
    return api.getSnapshot(context.orderId)
  },

  onAction: (action, context) => {
    if (!context.orderId) {
      return { ok: false, message: '缺少工单号' }
    }
    return api.handleAction({
      key: action.key,
      orderId: context.orderId,
      args: action.args,
    })
  },
})
```

## 5. 快照数据

`getOrderSnapshot()` 返回的快照和 `pushOrderData()` 推送的快照都会进入宿主的工单数据仓库。

### 简化快照 `EntryOrderSnapshot`

适合只有标题、状态、提单人和按钮的详情页：

```ts
interface EntryOrderSnapshot {
  orderId: string
  updatedAt: number
  /** 业务状态值，例如 0 / 1 或处理中 / 已完成；不是来源菜单 stage。 */
  status?: string
  title?: string
  creator?: string
  actions?: readonly ActionDescriptor[]
}
```

SDK 会把 `orderId` 和 `creator` 封装成宿主详情字段。需要自定义多个字段时，直接返回 protocol 中的完整 `OrderSnapshot`：

```ts
import type { OrderSnapshot } from '@ut/protocol'

const snapshot: OrderSnapshot = {
  orderId: 'WO20261026001',
  updatedAt: Date.now(),
  status: '0',
  statusText: '待办',
  title: '传输线路故障工单',
  fields: [
    { key: 'creator', label: '提单人', value: '王伟' },
    { key: 'site', label: '站点', value: '上海浦东' },
  ],
  actions: [
    { key: 'mark-read', label: '标记已读' },
  ],
}
```

字段和按钮契约：

| 字段 | 说明 |
| --- | --- |
| `orderId` | 必填，必须等于当前工单号。归属不一致的快照会被宿主丢弃。 |
| `updatedAt` | 必填，毫秒时间戳。每次状态变化后重新生成，并保持递增。旧快照不会覆盖新快照。 |
| `status` | 业务状态码，与来源菜单 stage 无关。 |
| `statusText` | 可选的状态展示文案。 |
| `title` | 详情页头部标题。 |
| `fields` | 详情字段，只做展示，不负责交互。 |
| `actions` | 子应用自定义按钮。按钮点击后会按 `key` 和 `args` 回传。 |

### 移动端默认按钮

移动端宿主会按详情页 URL 中的来源菜单 stage 自动补充默认按钮，默认按钮会和 `actions` 中的自定义按钮一起显示。stage 不是快照的 `status`，后者只表示业务状态：

| 来源菜单 stage | 默认按钮 key | 文案 |
| --- | --- | --- |
| `todo` | `reassign` | 转派 |
| `todo` | `save` | 暂存 |
| `todo` | `return` | 返单 |
| `pendingAcceptance` | `accept-now` | 立即接单 |

默认按钮不需要写进 `actions`。但子应用仍需要在 `onAction` 中处理宿主实际展示的 key；不支持的动作应返回 `{ ok: false, message }`。不要在 `actions` 中重复声明同一个默认 key，避免出现重复按钮。

## 6. 按钮动作

动作回调的签名是：

```ts
import type { ActionInvokePayload, ActionResult, WorkOrderContext } from '@ut/protocol'

onAction: (
  action: ActionInvokePayload,
  context: WorkOrderContext,
) => ActionResult | void | Promise<ActionResult | void>
```

推荐按 `key` 分支处理，并使用第二个参数的 `context.orderId`：

```ts
async onAction({ key, args }, context) {
  const orderId = context.orderId
  if (!orderId) return { ok: false, message: '缺少工单号' }

  if (key === 'mark-read') {
    await api.markRead(orderId, args)
    entryApp.pushOrderData(await api.getSnapshot(orderId))
    return { ok: true, message: '已标记为已读' }
  }

  return { ok: false, message: `不支持的操作：${key}` }
}
```

规则：

1. 业务成功返回 `{ ok: true }`，需要提示时可以附带 `message`。
2. 业务失败返回 `{ ok: false, message }`，宿主会显示这条提示。
3. 成功改变工单状态后，调用 `pushOrderData()` 推送最新快照，否则宿主页头和按钮不会更新。
4. `args` 是按钮声明时的业务参数，宿主会原样回传；写操作建议按 `key + args + orderId` 做幂等。
5. 快照里的每个自定义按钮 key，以及移动端实际展示的默认按钮 key，都应该有明确处理分支。

## 7. SDK 方法

### 推送工单快照

```ts
app.pushOrderData(snapshot)
```

握手完成前调用时，SDK 会缓存最后一份快照，连接建立后补发。

### 登记和取消待办订阅

用于把子应用产生的待办条目推到宿主列表或角标，不用于更新当前详情页快照。

```ts
app.pushSubscription({
  subId: 'order-WO20261026001',
  appName: app.appName,
  entityType: 'order',
  businessKey: 'WO20261026001',
  orderId: 'WO20261026001',
  title: '传输线路故障工单',
  summary: '等待处理',
  status: 'live',
  updatedAt: Date.now(),
  version: 1,
})

app.cancelSubscription('order-WO20261026001')
```

订阅也会在握手完成前缓存。`subId` 用于后续取消或更新同一条订阅。

### 上报上下文变化

```ts
app.updateContext({ orderType: 'network-fault' })
```

SDK 会合并本地上下文，并在已连接时通知宿主。只上报确实发生变化的上下文；工单号、工单类型等字段应始终和当前页面实际展示的数据保持一致。

### 通知宿主

```ts
app.notify.toast({ message: '保存成功', level: 'success' })
app.notify.toast('保存成功')
app.notify.close('user-cancel')
app.notify.navigate({
  route: '/alarm/:id',
  params: { id: 'WO20261026001' },
})
```

`close()` 和 `navigate()` 都是请求宿主执行动作。子应用不要自行调用 `window.close()`，也不要直接修改宿主的 `location` 或 `history`。

### 订阅状态

```ts
const off = app.subscribe((state) => {
  console.log(state.status, state.context, state.error)
})

off()
```

`state.status` 可能是：

| 状态 | 含义 |
| --- | --- |
| `connecting` | 已开始握手，等待宿主回应。 |
| `ready` | 已连接，可以与宿主通信。 |
| `standalone` | 没有宿主或握手超时，子应用可以继续独立运行。 |
| `closed` | 会话已销毁。 |

### 销毁会话

```ts
app.dispose()
```

页面级会话在组件卸载时销毁。模块级单例只在整个子应用根实例卸载时销毁，普通路由切换不要销毁。

## 8. 生命周期回调

| 回调 | 触发时机 | 建议处理 |
| --- | --- | --- |
| `onContextChange(context)` | 首次 welcome、首屏 `order.get` 合并上下文、工单切换或上下文更新 | 按新 `orderId` 加载业务数据。回调可能因首屏消息时序触发多次，处理应保持幂等。 |
| `onRefresh(context)` | 宿主要求刷新 | 重新请求业务数据并调用 `pushOrderData()`，可以返回 Promise。 |
| `onPause()` | 页面暂时被切走 | 停止轮询、长连接和高频任务。 |
| `onResume()` | 页面重新显示 | 恢复任务并重新加载当前工单。 |
| `onDestroy()` | 宿主销毁详情或链路关闭 | 清理计时器、业务订阅和连接。 |
| `onStateChange(state)` | SDK 状态变化 | 更新连接状态、埋点或调试日志。 |
| `onError(error)` | 协议、握手或链路异常 | 记录链路错误；业务失败用 `onAction` 返回 `{ ok: false }`。 |

## 9. 直接访问和独立运行

子应用没有被 Wujie 宿主加载时，SDK 会使用独立传输并在握手超时后进入 `standalone`：

- 页面仍然可以渲染和调试。
- 不会收到宿主下发的 `context`、刷新和按钮动作。
- `pushOrderData()`、`pushSubscription()` 和 `notify.*` 可以正常调用，但没有宿主时不会产生页面联动。
- 嵌入统一待办的业务主键必须使用 SDK 的 `context.orderId`。独立访问时，如果产品允许直接打开页面，可以由页面自己的路由参数提供兜底数据。

## 10. 常见问题

### 为什么 `getSnapshot()` 初始化时拿不到 context？

不要把 `getSnapshot` 当作 `createEntryApp` 的同步初始化回调。它只会在宿主发送 `order.get` 时执行，参数就是宿主传入的当前上下文：

```ts
getOrderSnapshot: (context) => {
  return api.getSnapshot(context.orderId!)
}
```

`app.context` 在会话创建瞬间可能仍是 `undefined`，页面需要通过 `subscribe` 或 `onContextChange` 等待握手状态更新。

### 为什么按钮没有更新？

检查以下内容：

- 快照的 `orderId` 是否等于当前工单号。
- 每次推送的 `updatedAt` 是否比上一份新。
- 状态变化后是否重新调用了 `pushOrderData()`。
- `onAction` 是否实现了自定义按钮和移动端默认按钮的 key。
- 浏览器是否仍在使用旧的 Vite 依赖缓存；更新本地 SDK tarball 后可用 `pnpm dev --force` 重建缓存。

### 为什么同一个子应用的两个工单串了上下文？

通常是宿主没有把唯一 `instanceId` 注入 Wujie，或子应用绕过 `createEntryApp` 自己创建了传输。整页接入应使用 `createEntryApp`，不要手动填写或覆盖 `instanceId`。

## 11. 接入自查

- [ ] 已安装版本匹配的 `@ut/protocol` 和 `@ut/sub-sdk`。
- [ ] `appName` 与宿主配置逐字一致。
- [ ] `createEntryApp()` 没有放在 React render 过程中重复执行。
- [ ] `getOrderSnapshot(context)` 使用参数中的 `context.orderId`。
- [ ] `getOrderSnapshot` 和 `pushOrderData` 返回的 `orderId` 正确。
- [ ] 每次状态变化都生成了新的 `updatedAt` 并推送快照。
- [ ] 自定义按钮和移动端默认按钮都能在 `onAction` 中处理。
- [ ] 业务失败返回 `{ ok: false, message }`。
- [ ] 页面通过 `subscribe` 读取上下文，并在正确的生命周期调用 `dispose()`。
- [ ] 页面直接访问时可以进入独立模式，不依赖宿主全局变量或手写 `postMessage`。
- [ ] 跳转使用 `notify.navigate()`，宿主上下文变化使用 `updateContext()`。
